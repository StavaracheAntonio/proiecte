/*
import com.cra.figaro.language.{Flip, Constant, Chain, Select}
import com.cra.figaro.library.compound.{ If, CPD}
import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.library.atomic.continuous.Uniform


object partial{

	def main ( args: Array[String]){
		
		/*
		val prezenta = Uniform( 0.0, 100.0)

		val speculatii =      
    		Apply( prezenta,          
    			(p: Double) =>            
    					if (prezenta > 60.0) 55.0           
    					else if ( prezenta > 40.0) 45.0                        
    					else 40.0
    			)
		
        */

    	
		val prezenta1 = Flip( 40.0)
		val prezenta2 = Flip( 60.0)
    	val sanseC1 = If (  prezenta1, Constant(55.0), If (prezenta2, Constant(45.0), Constant (40.0)) )
    	val sanseC2 = Constant (100.0) - sanseC1


    	val exitpoll = Select ( 0.7 -> "Candidat1",  0.3 -> "Candidat2")

        val CastigatorC1 =   
            Chain( sanseC1,          
                ( sanseC1: Double) =>            
                        if (sanseC1 > 50.0) true                                
                        else Constant false
                )


        val satisfacereVotant = If (  CastigatorC1, Constant(100.0), Constant (0.0) )

    	
        

        prezenta1.observe ( false)
        println(VariableElimination.probability( CastigatorC1, true ) )

        prezenta1.unobserve()


        def gt_80 ( v: Double) = v > 80 
        exitpoll.observe ( "Candidat1")
        println(Importance.probability(price, gt_80 _) )
        exitpoll.unobserve()


        def sa_gt50 ( v: Double) = v > 50
        println(Importance.probability( , gt_50 _) )

		
	}

}
*/
