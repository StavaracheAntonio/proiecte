import com.cra.figaro.language.{Flip, Select}
import com.cra.figaro.library.compound.If
import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.library.atomic.discrete.FromRange
import com.cra.figaro.language.Apply
import com.cra.figaro.language.Chain
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.language._
import com.cra.figaro.library.atomic.continuous.Uniform



object poker {


	val highBet = Flip(0.4)
	val lastHandWasBluff = Flip (0.6)
	val goodHand = Flip(0.03)

	def onePair (){
		def Hand = {
			val card1 = FromRange(1, 14)
			val card2 = FromRange(1, 14)
			card1 === card2
		}
		val pair = Hand
		println(VariableElimination.probability(pair, true))
	}

	def twoPairs (){
		def Hand = {
			val card1 = FromRange(1, 14)
			val card2 = FromRange(1, 14)
			val card3 = FromRange(1, 14)
			val card4 = FromRange(1, 14)

			card1 === card2 && card3 === card4 && ! (card1 === card3)
		}
		val pair = Hand
		println(VariableElimination.probability(pair, true))
	}

	def threeOfKind (){
		def Hand = {
			val card1 = FromRange(1, 14)
			val card2 = FromRange(1, 14)
			val card3 = FromRange(1, 14)

			card1 === card2 && card3 === card1
		}
		val pair = Hand
		println(VariableElimination.probability(pair, true))
	}

	

	val Bluff = If( lastHandWasBluff,
		If ( highBet,
			Select(0.8 -> "Bluff", 0.2 -> "honestBet"),
			Select(0.6 -> "Bluff", 0.4 -> "honestBet")),
		Select(0.2 -> "Bluff", 0.8 -> "honestBet"))


	val Hand1 =Select(0.1 -> 1, 0.2 -> 2, 0.3 -> 3, 0.4 -> 4)
	val Hand2 =Select(0.1 -> 1, 0.2 -> 2, 0.3 -> 3, 0.4 -> 4)

	def WinProb(){
		val result = Apply(Hand1, Hand2, (h1: Int, h2: Int) => h1 < h2)
		println(VariableElimination.probability(result, true))
	}

	def WinProb2( i: Int){
		Hand2.observe(i)
		val result = Apply(Hand1, Hand2, (h1: Int, h2: Int) => h1 < h2)
		println(VariableElimination.probability(result, true))
	}

	def main(args: Array[String]){
		
		WinProb()
		WinProb2(2)
		onePair()
		twoPairs()
		threeOfKind()
	}

	
}