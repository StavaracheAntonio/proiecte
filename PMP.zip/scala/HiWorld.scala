import com.cra.figaro.language.{Flip, Select}
import com.cra.figaro.library.compound.If
import com.cra.figaro.algorithm.factored.VariableElimination
object HelloWorld {
	val sunnyToday = Flip(0.2)

	val wrongSide = Flip (0.2)


/*
	val greetingToday_0 = If(sunnyToday,
		Select(0.6 -> "Hello, world!", 0.4 -> "Howdy, universe!"),
		Select(0.2 -> "Hello, world!", 0.8 -> "Oh no, not again"))
*/

	val sunnyTomorrow = If(sunnyToday, Flip(0.8), Flip(0.05))
	val greetingTomorrow = If(sunnyTomorrow,
		Select(0.6 -> "Hello, world!", 0.4 -> "Howdy, universe!"),
		Select(0.2 -> "Hello, world!", 0.8 -> "Oh no, not again"))



	// exercise 1
	val greetingToday = If ( wrongSide, 
		Select (1.0 -> "Oh, no, not again"),
		If(sunnyToday,
			Select(0.6 -> "Hello, world!", 0.4 -> "Howdy, universe!"),
			Select(0.2 -> "Hello, world!", 0.8 -> "Oh no, not again"))
	)



	def predict() {
		val result = VariableElimination.probability(greetingToday, "Hello, world!")
		println("Today’s greeting is \"Hello, world!\" " + "with probability " + result + ".")
	}

	def infer() {
		greetingToday.observe("Hello, world!")
		val result = VariableElimination.probability(sunnyToday, true)
		println("If today's greeting is \"Hello, world!\", today’s " + "weather is sunny with probability " + result + ".")
	}

	def learnAndPredict() {
		greetingToday.observe("Hello, world!")
		val result = VariableElimination.probability(greetingTomorrow, "Hello, world!")
		println("If today's greeting is \"Hello, world!\", " + "tomorrow's greeting will be \"Hello, world!\" " + "with probability " + result + ".")
	}

	def exercise_2(){
		greetingToday.observe("Oh no, not again")
		val result = VariableElimination.probability(sunnyToday, true)
		println("If today's greeting is \"Oh no, not again\", today’s " + "weather is sunny with probability " + result + ".")

	}

	def exercise_3_1(){
		val x = Flip(0.4)
		val y = Flip(0.4)
		val z = x
		val w = x === z
		println(VariableElimination.probability(w, true))
	}

	def exercise_3_2(){
		val x = Flip(0.4)
		val y = Flip(0.4)
		val z = y
		val w = x === z
		println(VariableElimination.probability(w, true))
	}


	def main(args: Array[String]) {
		//predict()
		//infer()
		//learnAndPredict()
		exercise_2()
		exercise_3_1()
		exercise_3_2()
	}
}


/*
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
object HelloWorldTest{
	def main(args: Array[String]){
 		val helloWorldElement = Constant("Hello world!")
 		val sampleHelloWorld = Importance(1000, helloWorldElement)
 		sampleHelloWorld.start()
 		
		println("Probability of Hello world:")
 		println(sampleHelloWorld.probability(helloWorldElement, "Hello world!"))
		println("Probability of Goodbye world:")
 		println(sampleHelloWorld.probability(helloWorldElement, "Goodbye world!"))
	}
}
*/