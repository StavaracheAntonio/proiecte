import com.cra.figaro.language._
import com.cra.figaro.library.compound._
import com.cra.figaro.algorithm.sampling._
 
object tenis4{
	
	class tennis4( probP1ServeWin: Double, probP1Winner: Double, probP1Error: Double, probP2ServeWin: Double, probP2Winner: Double, probP2Error: Double) {
		
		
		def play( p1Serves: Boolean, p1Sets: Element[Int], p2Sets: Element[Int], p1Games: Element[Int], p2Games: Element[Int]): Element[Boolean] = {
			// incepe jocul
			val p1WinsGame = if (p1Serves) Flip (probP1Winner - probP1Error) else Flip(1 - probP2Winner + probP2Error)

			
			//daca p1 castiga, incrementeaza p1 daca a castiga al 6lea set  
			val newP1Games = Apply(p1WinsGame, p1Games, p2Games, (wins: Boolean, p1: Int, p2: Int) => if (wins) { if (p1 >= 5) 0 else p1 + 1} else { if (p2 >= 5) 0 else p1})	
			
			//daca p2 castiga, incrementeaza p2 daca a castiga al 6lea set  
			val newP2Games = Apply(p1WinsGame, p1Games, p2Games, (wins: Boolean, p1: Int, p2: Int) => if (wins) {if (p1 >= 5) 0 else p2} else {if (p2 >= 5) 0 else p2 + 1})

			//seturile lui p1 + 1 daca castiga  5 jocuri +1
			val newP1Sets = Apply(p1WinsGame, p1Games, p1Sets, (wins: Boolean, games: Int, sets: Int) => if (wins && games == 5) sets + 1 else sets)
			// seturile lui p2 +1 daca castiga majoritatea din 5 jocuri
			val newP2Sets = Apply(p1WinsGame, p2Games, p2Sets, (wins: Boolean, games: Int, sets: Int) => if (!wins && games == 5) sets + 1 else sets)
			// se termina match daca p1 sau p2 au mai mult de doua seturi castigate
			val matchOver = Apply(newP1Sets, newP2Sets, (p1: Int, p2: Int) => p1 >= 2 || p2 >= 2)
			// daca p1 castiga returneaza true si da play cu celalalt la serva
			If(matchOver, Apply(newP1Sets, (sets: Int) => sets >= 2), play(!p1Serves, newP1Sets, newP2Sets, newP1Games, newP2Games))
		}
	}
 
	def main(args: Array[String]){

		
		val tenis = new tennis4(0.5, 0.5, 0.1, 0.5, 0.5, 0.2)
		var function = tenis.play(true, Constant(0), Constant(0), Constant(0), Constant(0))
		val algorithm = Importance(20, function)
		algorithm.start()
		println(algorithm.probability(function, true))
		algorithm.stop()
		
	}
 }


/*
 package lab7

import com.cra.figaro.language.Select
import com.cra.figaro.library.atomic.continuous.Uniform
import com.cra.figaro.language.{Element, Chain, Apply}
import com.cra.figaro.library.collection.Container
import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.algorithm.sampling.Importance

object ex3
{
    def main(args: Array[String])
    {
        //3 4 3 5 4 3 5 4 5 3 4 5 4 5 3 4 3 4
        val par = for {hole <- 0 until 18} yield args(hole).toInt

        val skill = Uniform(0.0, 8.0/13.0)
        val shots = Array.tabulate(18)((hole: Int) => Chain(skill, (s: Double) =>
                                Select(s/8.0 -> (par(hole)-2),
                                       s/2.0 -> (par(hole)-1),
                                       s -> par(hole),
                                       (4.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+1),
                                       (1.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+2))))

        val vars = for { i <- 0 until 18} yield shots(i)
        val sum = Container(vars:_*).reduce(+)
        def greaterThan80(s: Int) = s >= 80
        def greaterThan03(s: Double) = s >= 0.3

        skill.addConstraint(s => if(s >= 0.3) 1.0; else 0.0)
        println(Importance.probability(sum, greaterThan80 _))
        // sum.observe(80)
        // println(Importance.probability(skill, greaterThan03 _))

        val skill_player1 = Uniform(0.0, 8.0/13.0)
        
        val shots_player1 =  Array.tabulate(18)((hole: Int) => Chain(skill_player1, (s: Double) =>
                                                Select(s/8.0 -> (par(hole)-2),
                                                       s/2.0 -> (par(hole)-1),
                                                       s -> par(hole),
                                                       (4.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+1),
                                                       (1.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+2))))
        val skill_player2 = Uniform(0.0, 8.0/13.0)
        val shots_player2 =  Array.tabulate(18)((hole: Int) => Chain(skill_player2, (s: Double) =>
                                                Select(s/8.0 -> (par(hole)-2),
                                                       s/2.0 -> (par(hole)-1),
                                                       s -> par(hole),
                                                       (4.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+1),
                                                       (1.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(hole)+2))))
        val shots_p1 = for { i <- 0 until 18} yield shots_player1(i)
        val shots_p2 = for { i <- 0 until 18} yield shots_player2(i)
        val points_p1 = Array.tabulate(18)((hole: Int) => Apply(shots_p1(hole), shots_p2(hole), (p1: Int, p2: Int) =>
                                        if (p1 > p2) -1; else if (p1 < p2) 1; else 0))
        val p1 = for { i <- 0 until 18} yield points_p1(i)
        val total = Container(p1:_*).reduce(+)
        def greaterThan0(s: Int) = s > 0

        skill_player1.observe(0.5)
        skill_player2.observe(0.5)
        println(Importance.probability(total, greaterThan0 _))
    }
}

*/