import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous._
import com.cra.figaro.algorithm.factored.beliefpropagation._

import scalax.chart.api._

object lab12 extends App with scalax.chart.module.Charting {
	//def main(args: Array[String]) {

		val x0 = Apply(Normal(0.75, 0.3), (d: Double) => d.max(0).min(1))
		val y0 = Apply(Normal(0.4, 0.2), (d: Double) => d.max(0).min(1))

        val x = Flip(x0)
		val y = Flip(y0)

        val z = If(x === y, Flip(0.8), Flip(0.2))
        z.observe(false)

 		val veAnswer = VariableElimination.probability(y, true)

		var data = for ( i <- 1000 to 10000 by 1000 ) yield{
 			var totalSquaredError = 0.0
 
 			for { j <- 1 to 20 } {
 				val imp = Importance(i, y)
 				imp.start()
				val impAnswer = imp.probability(y, true)
				val diff = veAnswer - impAnswer
				totalSquaredError += diff * diff
			}

			val rmse = math.sqrt(totalSquaredError / 20)
			println(i + " samples: RMSE = " + rmse)
			
			(i, rmse)
		}
		println(data)
		val chart = XYLineChart(data)
		chart.saveAsPNG("chart1.png")
	//}

}