import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous
import scala.collection.mutable.ListBuffer


import scala.util.control.Breaks._


abstract class St {
	val dificulty: Element[Int]
 	def score: Element[Int]
 	def prize: Element[String]
}

class NextSt(current: St) extends St {
 		
	val dificulty = RichCPD ( current.dificulty,
		(OneOf ( 5)) -> Select( 0.5 -> current.dificulty - 1 , 0.5 -> current.dificulty),
		(OneOf ( 1)) -> Select( 0.5 -> current.dificulty + 1 , 0.5 -> current.dificulty),
		(*) -> Select( 0.33 -> current.dificulty + 1 , 0.33 -> current.dificulty, 0.33 -> current.dificulty - 1),
	)


 	val chance_high_score =  Apply ( Constant( dificulty), (dif: Int) => RichCPD ( dif,
 			(OneOf ( 4, 5)) -> Flip(0.3),
			(*) -> Flip (0.7)
 		)
 	)

	
	val score = Apply ( Constant( chance_high_score), (chance: Int) =>
		If(chance, discrete.Uniform(1, 3), discrete.Uniform(1, 2))
 	)


	val prize = RichCPD ( score,
		(OneOf ( 3)) -> Select( 0.8 -> "won prize", 0.2 -> "nothing"),
		(*) -> Select( 0.3 -> "won prize", 0.7 -> "nothing")
	)

}

class InitialSt() extends St {
 	
 	val dificulty = discrete.Uniform(1, 2)
 		

 	val chance_high_score =  Apply ( Constant( dificulty), (dif: Int) => RichCPD ( dif,
 			(OneOf ( 4, 5)) -> Flip(0.3),
			(*) -> Flip (0.7)
 		)
 	)


 	val score = Apply ( Constant( chance_high_score), (chance: Int) =>
		If(chance, discrete.Uniform(1, 3), discrete.Uniform(1, 2))
 	)
 		
 	val prize = RichCPD ( score,
		(OneOf ( 3)) -> Select( 0.8 -> "won prize", 0.2 -> "not prize"),
		(*) -> Select( 0.3 -> "won prize", 0.7 -> "not prize")
	)
}



object test_2{

	def stateSequence(n: Int): List[St] = {
		if (n == 0)
			List(new InitialSt())
		else {
			val last :: rest = stateSequence(n - 1)
			new NextSt(last) :: last :: rest
		}
	}


	def main(args: Array[String]) {

		val stateSeq = stateSequence(10)

		val level_4 = VariableElimination.probability( stateSeq(4).dificulty, 5)
		val level_9 = VariableElimination.probability( stateSeq(9).dificulty, 6)

		println ("level_4 - dif 5" + level_4)
		println ("level_9 - dif 5" + level_9)

		val alg = MPEVariableElimination()

		stateSeq(5).prize.observe ("won prize")
		stateSeq(6).prize.observe ("nothing")
		stateSeq(7).prize.observe ("nothing")


		println("most likely value lev_8 dif: " + alg.mostLikelyValue(stateSeq(8).dificulty))
		println("most likely value lev_9 dif: " + alg.mostLikelyValue(stateSeq(9).dificulty))

	
	}

}
