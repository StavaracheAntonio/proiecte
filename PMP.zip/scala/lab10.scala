import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous


object lab10 {
	val policy = 1

	def transition(investment : Double, capital : Double) : (Element[(Double, Double, Double)]) = {
		
		val newInvestment = Constant(policy * capital)
		val newProfit = Apply( continuous.Uniform(0.5, 2.0), (prec : Double ) => prec*investment) 
		val newCapital = Apply(newInvestment, newProfit, (newInvestment : Double, newProfit : Double) => capital + newProfit - newInvestment)
		
		^^(newInvestment, newProfit, newCapital)
	}

	def nextUniverse(previous : Universe) : Universe = {
		val next = Universe.createNew()
		
		val previousInvestment = previous.get[Double]("investment")
		val previousCapital = previous.get[Double]("capital")
		val a = previous.get[Double]("capital")
		
		val state = Chain(previousInvestment, previousCapital, transition _)
		
		Apply(state, (s : (Double, Double, Double)) => s._1)("investment", next)
		Apply(state, (s : (Double, Double, Double)) => s._2)("profit", next)
		Apply(state, (s : (Double, Double, Double)) => s._3)("capital", next)
		
		next
	}

	def main(args: Array[String]) {
		
		val initial = Universe.createNew()
		
		val capital = Constant(1000.0)("capital", initial)
		val investment = Apply(capital, (capital : Double) => policy*capital)("investment", initial)
		val profit = Constant(0.0)("profit", initial)
		
		val alg = ParticleFilter(initial, nextUniverse, 1000)
		alg.start()
		for ( i <- 1 to 11 ) {
			alg.advanceTime()
			println(alg.currentExpectation("capital", (i : Double) => i )) 
		}
		alg.stop()
	}
}