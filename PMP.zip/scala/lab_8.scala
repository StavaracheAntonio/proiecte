import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete._
import com.cra.figaro.algorithm.factored._


object lab8 extends ElementCollection{

	class Finance{
		val budget = Select ( 0.2 -> "low", 0.4 -> "medium", 0.4 -> "high")		
	}

	class HR( finance : Finance ){
		val experiencedHR = Flip(0.6)
		val hrCampaigns = If ( experiencedHR, Flip (0.9), Flip(0.3))
		val studySelectionEmployees = Select ( 0.2 -> "high studies", 0.5 -> "medium studies", 0.3 -> "unqualified")		
		val benefits = RichCPD ( finance.budget,
			(OneOf ( "medium", "high")) -> Select( 0.8 -> "high benefits", 0.2 -> "low benefits"),
			(*) -> Select( 0.3 -> "high benefits", 0.7 -> "low benefits")
		)

	}

	class ReasearchAndDevelopment ( finance: Finance, hr: HR) {
		val employeesQuality = RichCPD ( hr.benefits, hr.hrCampaigns, hr.studySelectionEmployees,
			( OneOf("high benefits"), OneOf (true), OneOf ( "medium studies", "high studies")) -> Select( 0.8 -> "qualified", 0.2 -> "unqualified"),
			(*, *, *) -> Select( 0.4 -> "qualified", 0.6 -> "unqualified")
		)
		val teamSize = Select ( 0.4 -> "small team", 0.5 -> "medium team", 0.1 -> "large team")
	}

	class Production ( finance: Finance, rd: ReasearchAndDevelopment){
		val productsQuality = RichCPD ( finance.budget, rd.employeesQuality, rd.teamSize, 
				(( OneOf ("high", "medium"),  OneOf("qualified"), OneOf("large team")) -> Select ( 0.1 -> "low", 0.2 -> "medium", 0.7 -> "high")),
				( OneOf("medium"), OneOf("qualified") , OneOf ("large team", "medium team")) -> Select ( 0.3 -> "low", 0.5 -> "medium", 0.2 -> "high"),
				((*, *, *) -> Select ( 0.33 -> "low", 0.33 -> "medium", 0.33 -> "high"))
			)
	}

	class Sales ( finance: Finance, prod: Production){
		val goodMarketingStrategy = RichCPD( finance.budget,
			(OneOf ("high", "medium")) -> Select (0.9 ->true, 0.1 -> false), 
			(*) -> Select (0.1 ->true, 0.9 -> false)
		)

		val sales = RichCPD( goodMarketingStrategy, prod.productsQuality, 
			( OneOf (true), OneOf("medium", "high")) -> Select ( 0.7 -> "high", 0.2 -> "medium", 0.1 -> "low"),
			( OneOf (false), OneOf("medium")) -> Select ( 0.1 -> "high", 0.7 -> "medium", 0.2 -> "low"),
			( OneOf (false), OneOf("low")) -> Select ( 0.2 -> "medium", 0.8 -> "low"),
			(*, *) -> Select ( 0.7 -> "high", 0.2 -> "medium", 0.1 -> "low")
		)
	}

	class Firm ( f: Finance, hr: HR, rd: ReasearchAndDevelopment, prod: Production, s: Sales){
		val health = RichCPD ( f.budget, prod.productsQuality, s.sales,
			( OneOf ("high", "medium"), OneOf ("high", "medium"), OneOf("high")) -> Select ( 0.1 -> "low", 0.25 -> "medium", 0.65 -> "high"),
			(*, *, *) -> Select ( 0.33 -> "low", 0.33 -> "medium", 0.33 -> "high")
		)
	}

	def main ( args: Array[String]){

		val f = new Finance
		val hr = new HR(f)
		val rd = new ReasearchAndDevelopment(f, hr)
		val p = new Production(f, rd)
		val s = new Sales(f, p)

		val firm = new Firm( f, hr, rd, p, s)

		f.budget.observe ( "high")
		println( VariableElimination.probability( firm.health, "high"))

		f.budget.observe ( "low")
		println( VariableElimination.probability( firm.health, "high"))

	}

}
