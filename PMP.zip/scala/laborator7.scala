import com.cra.figaro.language._
import com.cra.figaro.library.compound._
import com.cra.figaro.algorithm.sampling._
import scala.collection.mutable
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.library.atomic.continuous
import com.cra.figaro.language.Chain
import com.cra.figaro.library.compound.{RichCPD, OneOf, *}
import com.cra.figaro.language.{Flip, Constant, Apply}
import com.cra.figaro.algorithm.factored.VariableElimination

import com.cra.figaro.library.collection.Container
import com.cra.figaro.library.atomic.continuous.Uniform
import scala.language.implicitConversions


object Golf{
 
  def main(args: Array[String]){

    val ParV = List(5, 4, 3)
    //val par = Array.fill(18)(discrete.Uniform(ParV:_*))
    val P = List( 5, 3, 4, 4, 5, 3, 3, 4, 5, 3, 4, 4, 5, 3, 3, 4, 5, 4)
    
    val par = for {i <- 0 until 18} yield P(i)

    val skill = Uniform(0.0, 8.0/13.0)
      
    val shots = Array.tabulate(18)((i: Int) => Chain(skill, (s: Double) => Select(s/8.0 -> (par(i)-2), s/2.0 -> (par(i)-1), s -> par(i), (4.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(i)+1), (1.0/5.0) * (1.0 - (13.0 * s)/8.0) -> (par(i)+2))))
    val shotsV = for { i <- 0 until 18} yield shots(i)
   
    val sum = Container(shotsV:_*).reduce(_+_)
    

    
    def gT80(s: Int) = s > 80
    println(Importance.probability(sum, gT80 _))


    skill.addConstraint(s => if(s >= 0.3) 1.0; else 0.0)
    println(Importance.probability(sum, gT80 _))
    


    /*
    def gT3 (s: Double) = s > 0.3
    sum.observe(80)
    println(Importance.probability(skill, gT3 _))
    */
  }
 
 }