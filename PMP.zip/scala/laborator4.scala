import com.cra.figaro.language.{Flip, Select}
import com.cra.figaro.library.compound.If
import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.library.atomic.discrete.FromRange
import com.cra.figaro.language.Apply
import com.cra.figaro.language.Chain
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.language._
import com.cra.figaro.library.atomic.continuous.Uniform
import util.Random
import math._


abstract class Persoana

case class Student(nume:String, prenume:String, an:Integer, var materii:Array[(String, Int)]) extends Persoana {
	
	def setNota(materie: String, nota: Integer) {
  		for (i <- 0 until materii.length)
    		if (materii(i)._1 == materie)
    			materii(i) = (materie, nota)
	}
	
	def getNota(materie:String) = materii filter (_._1 == materie)

	
	def addMaterie(materie: String, nota: Int){
		materii = materii :+ (materie, nota)
	}
}

case class Profesor(nume:String, prenume:String, materie:String) extends Persoana {

}



object lab4{
	def getType (p:Persoana){
		if (p.isInstanceOf[Profesor]){
			var prof = p.asInstanceOf [Profesor]
			print ("Profesor" + " nume: " + prof.nume + " prenume: " + prof.prenume + " materie: " + prof.materie + "\n")
		}
		if (p.isInstanceOf[Student]){
			var stud = p.asInstanceOf [Student]
			print ("Student" + " nume: " + stud.nume + " prenume: " + stud.prenume + " an: " + stud.an + " \nmaterii: ")
			for (i <- 0 until stud.materii.size){
				print ("\n" + stud.materii(i)._1 + " : " + stud.materii(i)._2 + "\n")
			}
		}
	}

	def filterByYear (an: Int, s: Array[Student]) : Array[Student] = {
		var rez = Array[Student]()

		for (i <- 0 until s.size)
    		if (s(i).an == an){
    			rez = rez :+ s(i)
    		}
    	rez
	}


	// tabulate
	def getRandGrades ( materii: Array[String]) : Array[(String, Int)] = {
		var s = Seq.fill(materii.size)( abs (Random.nextInt) % 2)

		var rez = Array[(String, Int)]()
		for (i <- 0 until s.size)
    		if (s(i) == 1){
    			//print(materii(i), s(i))
    			var v = abs (Random.nextInt) % 10 + 1
    			rez = rez :+ (materii(i), v)
    		}else{
    			var v = -1.toInt
    			rez = rez :+ (materii(i), v)
    		}
    	
		rez
	}


	def main(args: Array[String]){
		var p = Profesor ("ionescu", "andrei", "java")
		var materii = Array ("PMP", "ML", "Python")

		var n =getRandGrades (materii)

		var S = Array[Student]()
		S = S:+ Student( "andreiescu", "andrei", 2, getRandGrades(materii))
		S = S:+ Student( "ionescu", "ion", 3, getRandGrades(materii))
		
		getType(p)
		getType(S(0))
		S(0).setNota("Python", 9)
		getType(S(0))
		S(0).addMaterie ("POO", 7)
		getType(S(0))

		var s = filterByYear(2, S)

		print ( "Studenti in anul 2: \n")
		for ( i <- 0 until s.size){
			print (s(i).nume+ " "+ s(i).prenume)
		}

		
	}
}