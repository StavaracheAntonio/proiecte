import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous._
import com.cra.figaro.algorithm.factored.beliefpropagation._

import scalax.chart.api._

object lab12_2 extends App with scalax.chart.module.Charting {
	

	//def main(args: Array[String]) {

		val x0_0 = Apply(Normal(0.75, 0.3), (d: Double) => d.max(0).min(1))
		val y0_0 = Apply(Normal(0.4, 0.2), (d: Double) => d.max(0).min(1))

        val x_0 = Flip(x0_0)
		val y_0 = Flip(y0_0)

        val z_0 = If(x_0 === y_0, Flip(0.8), Flip(0.2))
		z_0.observe(false)

		val veAnswer = VariableElimination.probability(y_0, true)
		
		val data = for ( i <- 10000 to 100000 by 10000 ) yield {
			var totalSquaredError = 0.0
			
			for { j <- 1 to 25 } {
				Universe.createNew()
		
				val x0 = Apply(Normal(0.75, 0.3), (d: Double) => d.max(0).min(1))
				val y0 = Apply(Normal(0.4, 0.2), (d: Double) => d.max(0).min(1))
        		val x = Flip(x0)
				val y = Flip(y0)

        		val z = If(x === y, Flip(0.8), Flip(0.2))
				z.observe(false)

				val mh = MetropolisHastings(i, ProposalScheme.default, y)

 				mh.start()
				val mhAnswer = mh.probability(y, true)
				val diff = veAnswer - mhAnswer
				totalSquaredError += diff * diff

			}

			val rmse = math.sqrt(totalSquaredError / 25)
			println(i + " samples: RMSE = " + rmse)

			(i, rmse)
 		}
 		println(data)
		val chart = XYLineChart(data)
		chart.saveAsPNG("chart2.png")

	//}

}