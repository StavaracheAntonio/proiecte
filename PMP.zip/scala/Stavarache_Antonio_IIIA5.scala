import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous
import scala.collection.mutable.ListBuffer


import scala.util.control.Breaks._

object  song_success{

	//  valoare prag pentru total exposed
	val stopping_threshold = 90000.0
	// valoare prag pentru total bought - oprirea algoritmului
	val saturation_threshold = 5000000.0


	def transition(x :(Double, Double, Double, Double, Double)) : (Element[(Double, Double, Double, Double, Double)]) = {
		
		// am ales ca fiecare element din universul nou creat sa depinda doar de altele din universul anterior

		val _quality = x._1
		val _newlyExposed = x._2
		val _totalExposed = x._3
		val _newlyBought = x._4
		val _totalBought = x._5

		// The Quality doesn’t change over time
		val quality = Constant (_quality)

		//the Total Bought is the previous Total Bought plus the Newly Bought, and similarly for Total Exposed
		val totalExposed =  Apply ( Constant(_totalExposed), Constant (_newlyExposed), (tExp: Double, nExp: Double) => nExp + tExp)
		val totalBought = Apply( Constant(_totalBought), Constant(_newlyBought), (tBght : Double, nBght : Double) => tBght + nBght)

		// verific daca total exposed a de pasit pragul in care este probabil sa mai avem o crestere majora a expunerii
		// este posibil sa nu mai existe oameni care pot fi expusi la cantec
		val over_saturated = Apply ( Constant (_totalExposed), Constant(saturation_threshold), (tExp : Double, threshold : Double) 
			=> if(tExp > threshold) true else false
		)
		

		// distributii in functie de cum vrem sa fie cresterea lui total_exposed
		val v_unif =continuous.Uniform( 10 * stopping_threshold, 0.1 * _totalExposed)
		val v_unif_1 =continuous.Uniform( 3 * stopping_threshold / 10, stopping_threshold/2)

		// calcul newly_exposed, in functie de newly_bought, total_exposed si tipul de crestere pe care il vom avea
		val newlyExposed = Apply(v_unif, v_unif_1, over_saturated, Constant (_newlyBought), Constant(_totalExposed),
			(v : Double, v1: Double, over_sat: Boolean, nBght : Double, tExp : Double) =>		
				if ( over_sat == false )
					v * sqrt (nBght) / sqrt (stopping_threshold)
				else
					v1
		)

		// calcul distributie pentru newly_bought in functie quality si newly_exposed
		val v_unif_2 = continuous.Uniform(2 * stopping_threshold / 3, 3 * _newlyExposed * _quality)
		val newlyBought = Apply(v_unif_2,
			(v : Double) =>
				v
		)

		// valorile din reteaua bayesiana in urma tranzitiei
		^^(quality, newlyExposed, totalExposed, newlyBought, totalBought)
	
	}

	def nextUniverse(previous : Universe) : Universe = {

		//implementarea tranzitiei valorilor dintre univeruri
		val next = Universe.createNew()
		
		val previousQuality = previous.get[Double]("quality")
		val previousNewlyExposed = previous.get[Double]("newly_exposed")
		val previousTotalExposed = previous.get[Double]("total_exposed")
		val previousNewlyBought = previous.get[Double]("newly_bought")
		val previousTotalBought = previous.get[Double]("total_bought")
		
		val state = Chain ( ^^(previousQuality, previousNewlyExposed, previousTotalExposed , previousNewlyBought, previousTotalBought), transition _)
		
		Apply(state, (s : (Double, Double, Double, Double, Double)) => s._1)("quality", next)
		Apply(state, (s : (Double, Double, Double, Double, Double)) => s._2)("newly_exposed", next)
		Apply(state, (s : (Double, Double, Double, Double, Double)) => s._3)("total_exposed", next)
		Apply(state, (s : (Double, Double, Double, Double, Double)) => s._4)("newly_bought", next)
		Apply(state, (s : (Double, Double, Double, Double, Double)) => s._5)("total_bought", next)

		next
	}



	def main(args: Array[String]) {

		/*
			subpunct a:
			Generate data from this model. Use particle filtering, with no evidence, to
			create a sequence of numbers of Newly Bought. Stop when Newly Bought
			falls below a certain threshold (corresponding to the song falling off the
			charts).
		*/

		val initial = Universe.createNew()
		
		// initializare valorilor starii initiale
		val quality = Constant(0.72)("quality", initial)

		val newly_exposed = continuous.Uniform(100000, 200000)("newly_exposed", initial)
		val newly_bought = continuous.Uniform(100000, 200000)("newly_bought", initial)

		val total_bought = Apply (newly_bought, (b : Double) => b )("total_bought", initial)
		val total_exposed = Apply (newly_exposed, (e : Double) => e )("total_exposed", initial)
		
		// lista in care am retinu valorile newly_bought
		var observes = new ListBuffer[Double]()

		// run particle filter

		val alg = ParticleFilter(initial, nextUniverse, 1000)
		alg.start()
		var i = 0
		breakable{
			
			while (true){ //no time limit on the amount of time a song stays in the

				i = i + 1
				alg.advanceTime ()

				val new_bght = alg.currentExpectation("newly_bought", (i : Double) => i )

				println ("newly_bought iteratia " + i +":")
				println (new_bght)

				observes += new_bght

				//Stop when Newly Bought falls below a certain threshold
				if (new_bght < stopping_threshold){
					break
				}
			}
		}
		alg.stop()

		/* 
			subpunct b:
			Now, using your generated data, observe Newly Bought and estimate the
			Total Exposed over time.
		*/

		// reinitializare valori
		val initial_2 = Universe.createNew()
		
		val quality_2 = Constant(0.72)("quality", initial_2)

		val newly_exposed_2 = continuous.Uniform(100000, 200000)("newly_exposed", initial_2)
		val newly_bought_2 = continuous.Uniform(100000, 200000)("newly_bought", initial_2)

		val total_bought_2 = Apply (newly_bought, (b : Double) => b )("total_bought", initial_2)
		val total_exposed_2 = Apply (newly_exposed, (e : Double) => e )("total_exposed", initial_2)
		
		val alg_2 = ParticleFilter(initial_2, nextUniverse, 1000)
		alg_2.start()
		i = 0
		breakable{
			
			while (true){
				
				// applic evidenta in cazul in care nu am depasit numarul de iteratii de la algoritmul din urma
				if (i < observes.length){
					var evidence = List( NamedEvidence( "newly_bought", Observation( observes( i)) ) )
					alg_2.advanceTime(evidence)
				}else{
					alg_2.advanceTime()
				}
				i = i + 1
				
				val new_bght = alg_2.currentExpectation("newly_bought", (i : Double) => i )

				// estimez total_exposed
				val new_total_exposed = alg_2.currentExpectation("total_exposed", (i : Double) => i )

				println ("total_exposed iteratia " + i +":")
				println (new_total_exposed)

				observes += new_bght
				if (new_bght < stopping_threshold){
					break
				}
			}
		}
		alg_2.stop()
	}
}