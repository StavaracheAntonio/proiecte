import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous
import com.cra.figaro.algorithm.factored.beliefpropagation._


object lab11 {
	

	def main(args: Array[String]) {
		

		println("subpunct a")	
		var isPresident = Flip(0.000000025)
		var isLeftHanded = If(isPresident, Flip(0.5), Flip(0.1))
		isLeftHanded.observe(true)
		println(VariableElimination.probability(isPresident, true))	
		println(BeliefPropagation.probability(isPresident, true))

		val algorithm = Importance(45000000, isPresident)
		
		algorithm.start()
		println(algorithm.probability(isPresident, true))
		algorithm.stop()

		println("subpunct b")
		var isPresident2 = Flip(0.000000025)
		var wasHarvardStudent = If (isPresident2, Flip(0.15), Flip(0.0005))
		wasHarvardStudent.observe(true)
		println(VariableElimination.probability(isPresident2, true))
		println(BeliefPropagation.probability(isPresident2, true))
		println(Importance.probability(isPresident2, true))

		var isPresident3 = Flip(0.000000025)
		var isLeftHanded3 = If(isPresident3, Flip(0.5), Flip(0.1))
		var wasHarvardStudent3 = If (isPresident3, Flip(0.15), Flip(0.0005))

		wasHarvardStudent3.observe(true)
		isLeftHanded3.observe(true)
		println(VariableElimination.probability(isPresident3, true))
		println(BeliefPropagation.probability(isPresident3, true))
		println(Importance.probability(isPresident3, true))		


	}
}