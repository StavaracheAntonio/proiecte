
import com.cra.figaro.library.compound.If
import com.cra.figaro.language.{Flip, Select}
import com.cra.figaro.algorithm.factored.VariableElimination
import com.cra.figaro.library.atomic.discrete.Binomial

import com.cra.figaro.language.Apply
import com.cra.figaro.language.Chain
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._

object obj{


	def makeStreaky(r1: Element[Boolean], r2: Element[Boolean]) {
		val pair = Apply(r1, r2, (b1: Boolean, b2: Boolean) => (b1, b2))
		pair.setConstraint((bb: (Boolean, Boolean)) =>
			if (bb._1 == bb._2) 1.0; else 0.5
		)
	}

	/*

	val size = CPD(subject,
		’people -> Select(p1 -> ’small, p2 -> ’medium, p3 -> ’large),
		’landscape -> Select(p4 -> ’small, p5 -> ’medium, p6 -> ’large)
	)

	val x1 = Select(0.1 -> 1, 0.2 -> 2, 0.3 -> 3, 0.4 -> 4)
	val x2 = Flip(0.6)
	val y = RichCPD(x1, x2,
		(OneOf(1, 2), *) -> Flip(0.1),
		(NoneOf(4), OneOf(false)) -> Flip(0.7),
		(*, *) -> Flip(0.9)
	)


	*/

	def main (args: Array[String]){
		val sunnyToday = Flip ( 0.2)
		val greetingToday = If ( sunnyToday,
			Select ( 0.6 -> "Hello sunny"), 
			Select ( 0.4 -> "Hello rainy")

		)

		val sunnyDaysInMonth = Binomial (30, 0.2)
		def getQuality ( i: Int): String = 
			if ( i > 10 ) "good"; else if ( i> 5) "average"; else "poor";

		val monthQuality = Apply( sunnyDaysInMonth, getQuality)

		//println ( VariableElimination.probability ( monthQuality, "good"))
		//println ( VariableElimination.probability(greetingToday, "Hello sunny"))

		val goodMood = Chain ( monthQuality, (s:String) =>
			if (s == "good") Flip (0.9)
			else if ( s == "average") Flip (0.6)
			else Flip (0.1) )
		println ( VariableElimination.probability(goodMood, true))

		sunnyDaysInMonth.setCondition((i: Int) => i > 8)
		println(VariableElimination.probability(goodMood, true))
		//Utilizarea de conditii multiple:
		//sunnyDaysInMonth.addCondition((i: Int) => i % 3 == 2)

		// utilizare varElim mai buna
		//val algorithm = VariableElimination(element1, element2)
		//algorithm.start()
		//println(algorithm.probability(element1, 0))
		//println(algorithm.probability(element1, (i: Int) => i > 0))

		val algorithm = Importance(10, goodMood)
		algorithm.start()
		println(algorithm.probability(goodMood, true))

	}
}