import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete._
import com.cra.figaro.algorithm.factored._


object exemplu{


	def game( ): Unit ={
		val p1 = Select ( 0.33 -> "piatra", 0.33 -> "hartie", 0.33 -> "foarfece" )
		val p2 = Select ( 0.33 -> "piatra", 0.33 -> "hartie", 0.33 -> "foarfece" )

		
		val p1WinsGame = Apply(p1, p2, (p1: String, p2: String) => (p1 == "piatra" && p2 == "foarfece") || (p1 == "foarfece" && p2 == "hartie") || (p1 == "hartie" && p2 == "piatra"))			

		val p2WinsGame = Apply(p1, p2, (p1: String, p2: String) => (p2 == "piatra" && p1 == "foarfece") || (p2 == "foarfece" && p1 == "hartie") || (p2 == "hartie" && p1 == "piatra"))			
		
		val jocORunda = Apply(p1WinsGame, p2WinsGame, (v1:Boolean, v2:Boolean) =>
      		if (v1) 1
      		else if (v2) -1
      		else 0)

		println ( VariableElimination.probability(jocORunda, 0))
	}

	def rec_game( p1Won: Element[Int]): Element[Boolean] ={

		val p1 = if (p1Won == Constant (1)) Select ( 0.22 -> "piatra", 0.66 -> "hartie", 0.11 -> "foarfece" ) 
      		else if (p1Won == Constant (0)) Select ( 0.66 -> "piatra", 0.22 -> "hartie", 0.11 -> "foarfece" ) 
      		else Select ( 0.33 -> "piatra", 0.33 -> "hartie", 0.33 -> "foarfece" )

      	val p2 = if (p1Won == Constant (-1)) Select ( 0.22 -> "piatra", 0.66 -> "hartie", 0.11 -> "foarfece" ) 
      		else if (p1Won == Constant (0)) Select ( 0.66 -> "piatra", 0.22 -> "hartie", 0.11 -> "foarfece" ) 
      		else Select ( 0.33 -> "piatra", 0.33 -> "hartie", 0.33 -> "foarfece" )


		val p1WinsGame = Apply(p1, p2, (p1: String, p2: String) => (p1 == "piatra" && p2 == "foarfece") || (p1 == "foarfece" && p2 == "hartie") || (p1 == "hartie" && p2 == "piatra"))			

		val p2WinsGame = Apply(p1, p2, (p1: String, p2: String) => (p2 == "piatra" && p1 == "foarfece") || (p2 == "foarfece" && p1 == "hartie") || (p2 == "hartie" && p1 == "piatra"))			

      	If(p1WinsGame, Constant (true), If(p2WinsGame, Constant(false), rec_game(Constant (0)))) 

	}

	def main( args: Array[String]){

		game()
		
		var function = rec_game( Constant (0))
		val algorithm = Importance(15, function)
		
		algorithm.start()
		println(algorithm.probability(function, true))
		algorithm.stop()
		
	}
}