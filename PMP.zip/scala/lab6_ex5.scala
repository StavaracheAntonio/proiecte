import com.cra.figaro.language._
import com.cra.figaro.library.compound._
import com.cra.figaro.algorithm.sampling._
 
object tenis5{
	
	class tennis5( probP1ServeWin: Double, probP1Winner: Double, probP1Error: Double, probP2ServeWin: Double, probP2Winner: Double, probP2Error: Double) {
		
		
		def game( p1Serves: Boolean, p1Points: Element[Int], p2Points: Element[Int]): Element[Boolean] = {
			//player1 a castigat setul
			val p1WinsPoint = if (p1Serves) Flip (probP1ServeWin - probP1Error)
						  else Flip( 1 - probP2ServeWin + probP2Error)

			//puncte player1 
			val newP1Points = Apply(p1WinsPoint, p1Points, (wins: Boolean, points: Int) => if (wins) points + 1 else points)
			
			//puncte player2
			val newP2Points = Apply(p1WinsPoint, p2Points, (wins: Boolean, points: Int) => if (wins) points else points + 1)
			
			//player1 castiga daca p1>4, iar diferenta de puncte este >=2
			val p1WinsGame = Apply(newP1Points, newP2Points, (p1: Int, p2: Int) => p1 >= 4 && p1 - p2 >= 2)			

			//player2 castiga daca p2>4, iar diferenta de puncte este >=2
			val p2WinsGame = Apply(newP2Points, newP1Points, (p2: Int, p1: Int) => p2 >= 4 && p2 - p1 >= 2)

			//jocul se termina atunci cand castiga un player
			val gameOver = p1WinsGame || p2WinsGame

			// returneaza daca player 1 a castigat in cazul in care s-a terminat jocul, altfel incepe alt joc
			If(gameOver, p1WinsGame, game(p1Serves, newP1Points, newP2Points))			
		}
		
		def play( p1Serves: Boolean, p1Sets: Element[Int], p2Sets: Element[Int], p1Games: Element[Int], p2Games: Element[Int]): Element[Boolean] = {
			// incepe jocul
			val p1WinsGame = game(p1Serves, Constant(0), Constant(0))
			
			//daca p1 castiga, incrementeaza jocurile lui p1 daca a castiga al 6lea set  
			val newP1Games = Apply(p1WinsGame, p1Games, p2Games, (wins: Boolean, p1: Int, p2: Int) => if (wins) { if (p1 >= 5) 0 else p1 + 1} else { if (p2 >= 5) 0 else p1})	
			
			//daca p2 castiga, incrementeaza jocurile lui p2 daca a castiga al 6lea set  
			val newP2Games = Apply(p1WinsGame, p1Games, p2Games, (wins: Boolean, p1: Int, p2: Int) => if (wins) {if (p1 >= 5) 0 else p2} else {if (p2 >= 5) 0 else p2 + 1})

			//incrementam seturile lui p1 daca acesta castiga  5 jocuri + 1
			val newP1Sets = Apply(p1WinsGame, p1Games, p1Sets, (wins: Boolean, games: Int, sets: Int) => if (wins && games == 5) sets + 1 else sets)
			
			//incrementam seturile lui p1 daca acesta castiga  5 jocuri + 1
			val newP2Sets = Apply(p1WinsGame, p2Games, p2Sets, (wins: Boolean, games: Int, sets: Int) => if (!wins && games == 5) sets + 1 else sets)
			
			// se termina match daca p1 sau p2 au mai mult de doua seturi castigate
			val matchOver = Apply(newP1Sets, newP2Sets, (p1: Int, p2: Int) => p1 >= 2 || p2 >= 2)
			
			// daca p1 castiga returneaza true si joaca cu serva celuilalt jucator
			If(matchOver, Apply(newP1Sets, (sets: Int) => sets >= 2), play(!p1Serves, newP1Sets, newP2Sets, newP1Games, newP2Games))
		}
	}
 
	def main(args: Array[String]){

		
		val tenis = new tennis5(0.5, 0.5, 0.1, 0.5, 0.5, 0.2)
		var function = tenis.play(true, Constant(0), Constant(0), Constant(0), Constant(0))
		val algorithm = Importance(20, function)
		algorithm.start()
		println(algorithm.probability(function, true))
		algorithm.stop()
		
	}
 }