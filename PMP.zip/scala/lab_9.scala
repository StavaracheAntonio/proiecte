import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.factored._


object lab9{

	def main ( args: Array[String]){
		val length = 11
		val chapterDifficulty: Array [Element [Int]] = Array.fill(length)(Constant ( 0))
		val learnGrade: Array [Element [Int]] = Array.fill(length)(Constant ( 0))
		
		// previous knowledge
		learnGrade(0) = discrete.Uniform(1, 10)

		for { i <- 1 until length} {
			chapterDifficulty(i) = discrete.Uniform( i, 10)

			learnGrade(i) = Chain ( learnGrade(i-1), chapterDifficulty(i), 
				(lastLearned : Int, difficulty : Int) =>
					discrete.Uniform ( ( (10 - difficulty)  +  lastLearned ) / 2, 10)
			)
		}

		val testPassed: Array [Element [Boolean]] = Array.fill(length)(Constant ( false))

		for { i <- 1 until length} {

			val score = Chain ( learnGrade(i), 
				(learnGrade : Int) =>
					discrete.Uniform ( learnGrade, 10 )
			)

			testPassed (i) = Chain ( score, 
				( score : Int) =>
					Flip( score / 10.0)
			) 
		}


		println ("test 10 passed without observes: " + VariableElimination.probability( testPassed(10), true) )


		testPassed(1).observe(true)
		testPassed(2).observe(true)
		testPassed(3).observe(true)

		println ("test 10 passed knowing that first 3 tests were passed: " + VariableElimination.probability( testPassed(10), true) )		

		testPassed(8).observe(true)
		println ("test 10 passed knowing that test 8 was passed: " + VariableElimination.probability( testPassed(10), true) )	


	}
}