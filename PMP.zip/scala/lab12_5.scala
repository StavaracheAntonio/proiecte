import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous._
import com.cra.figaro.algorithm.factored.beliefpropagation._

object lab12_5 {
	

	def main(args: Array[String]) {

		val x1 = Flip(0.999)
		val y1 = Flip(0.99)
		val z1 = Flip(0.9999)
		val z2 = Flip(0.0001)
		val z = If( x1 === y1, z1, z2)
		z.observe(false)
		println(VariableElimination.probability(y1, true))
		
		val scheme: ProposalScheme = {
		    DisjointScheme(
				(0.1, () => ProposalScheme(z1)), (0.1, () => ProposalScheme(z2)), (0.8, () => ProposalScheme(x1, y1)))
		}
				
		val alg2 = MetropolisHastings(10000000, scheme, y1)
		alg2.start()
		alg2.stop()
		println(alg2.probability(y1, true))
	}
}