import scala.math._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.language._
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.filtering._
import com.cra.figaro.library.atomic.continuous._
import com.cra.figaro.algorithm.factored.beliefpropagation._


object lab12_3 {
	

	def main(args: Array[String]) {

		val x = Flip(0.999)
		val y = Flip(0.99)
		val z = If(x === y, Flip(0.9999), Flip(0.0001))
		z.observe(false)

		val veAnswer = VariableElimination.probability(y, true)

		println("veAnswer = " + veAnswer)

		val algorithm = Importance(1000000, y)

		algorithm.start()
		println(algorithm.probability(y, true))
		algorithm.stop()
	}

}