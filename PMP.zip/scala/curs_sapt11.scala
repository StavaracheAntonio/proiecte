import com.cra.figaro.language._
import com.cra.figaro.algorithm.sampling._
import com.cra.figaro.library.compound._
import com.cra.figaro.library.atomic.discrete
import com.cra.figaro.algorithm.factored._
import com.cra.figaro.algorithm.factored.beliefpropagation._

object curs11 extends ElementCollection{


	class A {
		val e1 = Flip(0.5)
		val e21: Element[Boolean] = Apply(e1, (b: Boolean) => b)
		val e31: Element[Boolean] = Apply(e21, (b: Boolean) => b)
		val e22: Element[Boolean] = Apply(e1, (b: Boolean) => b)
		val e32: Element[Boolean] = Apply(e31, (b: Boolean) => b)
		val e4: Element[Boolean] = e31 === e32
	}

	class B {

		val e1 = Flip(0.5)
		val e21: Element[Boolean]  = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)
		val e31: Element[Boolean]  = CPD(e21,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)
		val e22: Element[Boolean]  = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)
		val e32: Element[Boolean]  = CPD(e31,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)
		val e4: Element[Boolean] = e31 === e32
		
	}

	class C ( length : Int){
		// Am rescris modelul din clasa B pentru a descrie un nou graf ce are muchiile e21 si e22 multiplicate.
		// Oricat am mari dimensiunea modelului este necesar acelasi numar de iteratii pentru BeliefPropagation ca la modelul precedent.

		val e2: Array [Element [Boolean]] = Array.fill(length)(Constant ( true))
		val e3: Array [Element [Boolean]] = Array.fill(length)(Constant ( true))
		val e1 = Flip(0.5)

		e2(0) = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false))
		e3(0) = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false))

		for { i <- 1 until length - 1} {
			e2(i) = CPD(e2(i-1),
				true -> Select(0.9998 -> true, 0.0002 -> false),
				false -> Select(0.9999 -> true, 0.0001 -> false))
			e3(i) = CPD(e3(i-1),
				true -> Select(0.9998 -> true, 0.0002 -> false),
				false -> Select(0.9999 -> true, 0.0001 -> false))
		}
		e2(length-1) = CPD(e2(length-2),
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false))
		e3(length-1) = CPD(e2(length-1),
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false))

		val e4 = e2(length-1) === e3(length-1)
		
		def beliefPropagation( begin: Int, end: Int){
			println ("length model: " + length)
			for { i <- 1 until end - begin + 1} {
				val algorithm = BeliefPropagation( i + begin, e4)
				algorithm.start()
				println ("Belief Propagation with " + (i + begin) + " iterations for fully randomized model: " + algorithm.probability(e4, true))
			}
		}
	}

	class D ( length : Int){
		// Am procedat la fel ca la clasa B doar ca am ales sa aplic nedeterminismul doar la inceputul modelului,
		// (elementele 0 din tablourile e2 si e3).
		// Numarul necesar de iteratii devine acum comparabil cu dimensiunea grafului.
		
		val e2: Array [Element [Boolean]] = Array.fill(length)(Constant ( true))
		val e3: Array [Element [Boolean]] = Array.fill(length)(Constant ( true))
		val e1 = Flip(0.5)

		e2(0) = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)

		e3(0) = CPD(e1,
			true -> Select(0.9998 -> true, 0.0002 -> false),
			false -> Select(0.9999 -> true, 0.0001 -> false)
		)

		for { i <- 1 until length - 1} {
			e2(i) = Apply(e2(i-1), (b: Boolean) => b)
			e3(i) = Apply(e3(i-1), (b: Boolean) => b)
		}

		e2(length-1) = Apply(e2(length-2), (b: Boolean) => b)
		e3(length-1) = Apply(e2(length-1), (b: Boolean) => b)

		val e4 = e2(length-1) === e3(length-1)
		
		def beliefPropagation( begin: Int, end: Int){
			println ("length model: " + length)
			for { i <- 1 until end - begin + 1} {
				val algorithm = BeliefPropagation( i + begin, e4)
				algorithm.start()
				println ("Belief Propagation with " + (i + begin) + " iterations for last model with only first elements randomized: " + algorithm.probability(e4, true))
			}
		}
	}

	def main ( args: Array[String]){

		val model1 = new A
		val model2 = new B

		println("Beliefe Propagation for badly designed model: " + BeliefPropagation.probability(model1.e4, true))
		println("Variable Elimination for badly designed model: " + VariableElimination.probability(model1.e4, true))

		println("Beliefe Propagation for last model with noise: " + BeliefPropagation.probability(model2.e4, true))
		println("Variable Elimination for last model with noise: " + VariableElimination.probability(model2.e4, true))

		for { i <- 1 until 10} {
			val algorithm = BeliefPropagation( i, model2.e4)
			algorithm.start()
			println(algorithm.probability(model2.e4, true))

		}

		val model3 = new C(100)
		model3.beliefPropagation(5, 7)
		val model32 = new C(300)
		model32.beliefPropagation(5, 7)

		val model4 = new D(100)
		model4.beliefPropagation(205, 207)
		val model5 = new D(300)
		model5.beliefPropagation(605, 607)
		
	}

}