#include "TSP.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;


void TSP::init(int & ci) {
	cout << "Alegeti modul de introducere al grafului:\n";
	cout << "1. Tastatura\n";
	cout << "2. Fisier text\n";
	cout << "3. Graf generat aleator\n";
	cin >> ci;
	system("CLS");

	srand(time(NULL));
	for (int i = 1; i <= 1000000; ++i)
		rand();

}

float TSP::rand_float_subunitar()
{
	float x = (float(rand() % 32000 + 1) / 32000.0f) * (float(rand() % 32000 + 1) / 32000.0f);
	return x;
}

Cromozome::Cromozome(int dim1) {
	dim = dim1;
	X = new int[dim * sizeof(int)];
	for (int i = 0; i < dim; ++i)
		X[i] = rand() % (dim - i);
}

void Cromozome::cpy(Cromozome & C2) {
	dim = C2.dim;
	for (int i = 0; i < dim; ++i)
		X[i] = C2.X[i];
}

void Cromozome::cross(Cromozome & a) {
	int d = dim;
	for (int i = 1 + (rand() % (d - 1)); i < d; ++i)
		swap(this->X[i], a.X[i]);
}

void Cromozome::mutation(float pm) {
	for (int i = 0; i < dim; ++i) {
		if (TSP::rand_float_subunitar() < pm) {
			if (rand() % 2)
				X[i] = (X[i] + 1) % (dim - i);
			else
				X[i] = (X[i] - 1) % (dim - i);
		}
		if (X[i] < 0) X[i] += 30;
	}
}

Cromozome::~Cromozome() {
	delete (X);
}

TSP::TSP(int input, int nodes, int pop_size1, int gen, int rul, float pc1, float pm1) {
	num_nodes = nodes;
	switch (input) {
	case 1:
		get_console_graph();
		break;
	case 2:
		get_file_graph();
		break;
	case 3:
		get_rand_graph();
		break;
	}
	NrGen = gen;
	rulari = rul;
	pop_size = pop_size1;
	pc = pc1;
	pm = pm1;
}

void TSP::get_console_graph() {
	int num_edge, a, b, val;
	cout << "Numar de noduri: "; cin >> num_nodes;
	cout << "Numar de muchii: "; cin >> num_edge;
	cout << "Introduceti cele 2 noduri intre care exista muchie si costul muchiei\n";
	for (int i = 0; i < num_nodes; ++i)
		for (int j = 0; j < num_nodes; ++j)
			A[edge(i, j)] = -1;
	for (int i = 1; i <= num_edge; i++) {
		cin >> a >> b >> val;
		A[edge(a, b)] = val;
	}
}

void TSP::get_file_graph() {
	int num_edge, a, b, val;
	ifstream fin("input.txt");
	fin >> num_nodes;
	fin >> num_edge;
	for (int i = 0; i < num_nodes; ++i)
		for (int j = 0; j < num_nodes; ++j)
			A[edge(i, j)] = -1;
	for (int i = 1; i <= num_edge; i++) {
		fin >> a >> b >> val;
		A[edge(a, b)] = val;
	}
}

void TSP::get_rand_graph() {
	for (int i = 0; i < num_nodes; ++i)
		for (int j = 0; j < num_nodes; ++j)
			A[edge(i, j)] = -1;
	for (int i = 0; i <= num_nodes * num_nodes; ++i) {
		int a = rand() % num_nodes;
		int b = rand() % num_nodes;
		A[edge(a, b)] = rand() % 1000;
	}
}

void TSP::bkt(int k, int curr) {
	solact[k] = curr;
	x[curr] = 1;
	if (k == num_nodes - 1) {
		if (A[edge(solact[k], solact[0])]>0) {
			int sum = 0;
			for (int i = 0; i < num_nodes - 1; i++) {
				sum += A[edge(solact[i], solact[i + 1])];
			}
			sum += A[edge(solact[num_nodes - 1], solact[0])];
			if (sum < best_val) {
				for (int i = 0; i<num_nodes - 1; i++)
					sol[i] = solact[i];
				sol[num_nodes - 1] = solact[num_nodes - 1];
				best_val = sum;
			}
			sum = 0;
		}
	}
	else {
		for (int i = 0; i < num_nodes; i++)
			if (A[edge(curr, i)]>0 && x[i] == 0) {
				bkt(k + 1, i);
				x[i] = 0;
			}
	}
}

void TSP::StartBKT() {
	memset(x, 0, sizeof(x));
	memset(sol, 0, sizeof(sol));
	best_val = 999999999;
	for (int i = 0; i < num_nodes; i++) {
		bkt(0, i);
		memset(x, 0, sizeof(x));
	}
}

void TSP::cross_over(float pc) {

	Cromozome* first = NULL, *last = NULL;
	int j;

	for (int i = 0; i < pop_size; ++i) {
		if (TSP::rand_float_subunitar() < pc) {
			last = V[i];
			for (j = i + 1; j < pop_size; ++j) {
				if (TSP::rand_float_subunitar() < pc) {
					V[j]->cross(*V[i]);
					last = NULL;
					i = j + 1;
					j = pop_size + 5;
				}
			}
			if (j < pop_size + 3)
				i = pop_size;
		}
		else {
			if (first == NULL)
				first = V[i];
		}

		if (last && first && TSP::rand_float_subunitar() < 0.5) {
			first->cross(*last);
		}
	}
}

void TSP::Recombina() {
	cross_over(pc);
	for (int i = 0; i < pop_size; ++i)
		V[i]->mutation(pm);
}

void TSP::Genereaza() {
	for (int i = 0; i < pop_size; ++i) {
		V[i] = new Cromozome(num_nodes);
		W[i] = new Cromozome(num_nodes);
	}
}

void TSP::Evalueaza() {
	//evalueaza populatie
	for (int i = 0; i < pop_size; ++i) {
		Cromozome_to_Int(V[i], x);
		ev[i] = f(eval(x));
	}
	//fitnessul total
	float T = 0;
	for (int i = 0; i < pop_size; ++i) {
		T += ev[i];
	}
	//PROB.SEL.INDIVIDUALE
	for (int i = 0; i < pop_size; ++i)
		p[i] = ev[i] / T;
	//PROB.SEL.CUMULATE
	q[0] = 0;
	for (int i = 0; i < pop_size - 1; ++i)
	{
		q[i + 1] = q[i] + p[i];
	}
	q[pop_size - 1] = 1;
}

void TSP::Cromozome_to_Int(Cromozome *a, int *w) {
	int y[500];
	for (int i = 0; i < a->dim; ++i) y[i] = 0;

	int k;
	for (int i = 0; i < a->dim; ++i) {
		k = -1;
		for (int j = 0; k < a->X[i]; ++j) {
			if (j >= a->dim) j = 0;
			if (y[j] == 0) k++;
			if (k == a->X[i]) {
				w[i] = j;
				y[j] ++;
				k++;
			}
		}
	}
}

float TSP::eval(int * v) {
	int c = 0;
	int s = 0;
	float f = 0.0f;
	for (int i = 0; i < num_nodes - 1; ++i) {
		if (A[edge(v[i], v[i + 1])] != -1) {
			c++;
			s += A[edge(v[i], v[i + 1])];
		}
	}
	if (A[edge(v[num_nodes - 1], v[0])] != -1) {
		c++;
		s += A[edge(v[num_nodes - 1], v[0])];
	}
	if (c <= num_nodes)
		f = float(c) / float(num_nodes);
	if (c == num_nodes) {
		f += 1.0f / s;
		if (f > best && c == num_nodes) {
			best_val = s;
			best = f;
			for (int i = 0; i < num_nodes; ++i)
				sol[i] = v[i];
		}
	}
	//printf("%d\n", s);
	return f;
}

void TSP::Selecteaza() {
	for (int i = 0; i < pop_size; ++i) {
		float r = rand_float_subunitar();
		int j = 0;
		while (q[j] < r) {
			j++;
		}
		W[i]->cpy(*V[j - 1]);
	}

	for (int i = 0; i < pop_size; ++i) {
		V[i]->cpy(*W[i]);
	}
}

void TSP::calc() {
	float min_timp = 3120321;
	for (int k = 0; k < rulari; ++k) {
		int t = 0;
		best_val = 100000000;
		clock_t start = clock();
		best = 0.0f;
		Genereaza();
		Evalueaza();
		for (t = 0; t < NrGen; ++t) {
			Selecteaza();
			Recombina();
			Evalueaza();
		}
		clock_t end = clock();
		float secunde = (float)(end - start) / CLOCKS_PER_SEC;

		if (secunde < min_timp)
			min_timp = secunde;
	}
}

float TSP::f(float a) {
	return a;
}

void TSP::StartHC( ) {
	int global_best = 100000000;
	hc = new Cromozome(num_nodes);
	Cromozome * hc2 = new Cromozome(num_nodes);

	for (int t = 1; t <= 15; ++t) {
		best = 0.0f;
		best_val = 10000000;
		bool found = true;
		hc2 = new Cromozome(num_nodes);
		int w[100];

		while (found) {
			found = false;
			int a, r;
			float b;
			a = -1;
			for (int i = 0; i < hc2->dim; ++i) {
				hc2->X[i] = (hc2->X[i] + 1) % (hc2->dim - i);
				Cromozome_to_Int(hc2, w);
				b = best;
				r = eval(w);
				if ( b < r){
					a = 0;
					i = hc2->dim + 10;
				}
				else {
					hc2->X[i] = (hc2->X[i] - 1) % (hc2->dim - i);
				}
			}
			if (a == 0) {
				hc->cpy( * hc2);
				//best = eval(hc->X);
				found = true;
			}
		}
		if (best_val < global_best)
			global_best = best_val;
	}
	best_val = global_best;
}