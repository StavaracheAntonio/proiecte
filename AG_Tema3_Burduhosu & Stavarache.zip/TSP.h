#pragma once
#include <stdio.h>      
#include <stdlib.h> 
#include <time.h> 
#include <math.h>
#include <iostream>
#include <map>


#define PI 3.14159265

using namespace std;

typedef pair<int, int> edge;
typedef map<edge, int> graph;

class Cromozome {
public:
	int dim;
	int * X;
	Cromozome(int dim1);
	void cpy(Cromozome & C2);
	void cross(Cromozome & a);
	void mutation(float pm);
	void get_first();
	~Cromozome();
};

class TSP {
public:
	graph A;
	void get_rand_graph();
	void get_console_graph();
	void get_file_graph();

	void bkt(int k, int curr);
	void StartBKT();

	float ev[10000], T, p[10000], q[10000];

	int num_nodes;
	int pop_size;
	int NrGen, rulari;
	float pc, pm;

	float best;
	int best_val;

	Cromozome* V[10000];
	Cromozome* W[10000];

	TSP(int input, int nodes, int pop_size1, int gen, int rul, float pc1, float pm1);

	float f(float a);
	void Evalueaza();
	void cross_over(float pc);

	void Genereaza();
	void Recombina();
	void Selecteaza();

	int solact[100], sol[500];
	int x[500];

	static void init(int &);
	static float rand_float_subunitar();

	void Cromozome_to_Int(Cromozome *a, int *w);

	float eval(int *v);

	void StartHC();
	Cromozome* hc;
	Cromozome* hc2;

	void calc();
};










