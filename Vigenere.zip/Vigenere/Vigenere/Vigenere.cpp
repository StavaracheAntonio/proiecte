#include "pch.h"
#include <iostream>
#include <fstream>
#include "Cypher.h"
#include "Adversar.h"

using namespace std;

ifstream fin ( "text.in" );

char * citire(char *);
char text[100000];

int main()
{
	citire(text);

	Cypher* A = new Cypher("ABABAAAB");
	char * q = nullptr;
	q = A->filtrare(text, q);
	//printf("%s\n", q);

	char * c = nullptr;
	c = A->criptare(q, c);
	//printf("%s\n", c);

	Adversar * C = new Adversar(c, 100);
	C->cautare();

	char * b = nullptr;
	Cypher * B = new Cypher(C->B->inv_key);
	b = B->criptare(c, b);
	printf("%s\n", b);
	printf("\n%s\n", C->B->inv_key);
	printf("\n%s\n", C->B->get_key());
	printf("%d\n", C->B->m);
}

char * citire(char * a) {
	char* b = new char[500];
	memset(b, 0, 500);
	while (fin.getline(b, 500) ) {
		strcat(a, b);
		memset(b, 0, 500);
	}
	return a;
}


