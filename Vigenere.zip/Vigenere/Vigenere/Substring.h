#pragma once

class Substring {
public:
	char * str = NULL;
	char * shiftedStr = NULL;
	int ln;
	int f[26] = { 0 };
	int shF[26] = { 0 };

	float pbs[26] = { 8.55f, 1.60f, 3.16f, 3.87f, 12.10f, 2.18f, 2.09f, 4.96f, 7.33f, 0.22f,
	0.81f, 4.21f, 2.53f, 7.17f, 7.47f, 2.07f, 0.10f, 6.33f, 6.73f, 8.94f, 2.68f, 1.06f, 1.83f, 0.19f, 1.72f, 0.11f };

	float IC = 0.0f;
	float MIC = 0.0f;
public:
	int shiftIndex = 0;
	void set(char * text, int pas, int index);
	float getIC();
	float getMIC();
	void shift(int index);

	void best_shift();
};

void Substring::best_shift() {
	int bestShift = 0;
	float bestDelta = 2.0f;

	for (int i = 0; i < 26; ++i) {
		shiftIndex = i;
		shift(i);

		float v = getMIC();
		if (abs(v - 0.065f) < bestDelta) {
			bestDelta = abs(v - 0.065f);
			bestShift = shiftIndex;
		}
	}
	shiftIndex = bestShift;
}

void Substring::set(char * text, int pas, int index) {
	if ( str != NULL)
		delete (str);

	for (int i = 0; i < 26; ++i) f[i] = 0;
	
	str = new char[strlen(text) / pas + 2];
	
	int l = strlen(text);
	int j = 0;

	for (int i = index; i < l; i = i + pas) {
		str[j] = text[i];
		f[str[j] - 'A'] ++;
		j++;
	}
	str[j] = 0;
	ln = j;

	if (shiftedStr != NULL)
		delete (shiftedStr);
	
	shiftedStr = new char[ ln + 2];
	getIC();
}
float Substring::getIC() {
	IC = 0.0f;
	for (int i = 0; i < 26; ++i)
		IC += (float(f[i]) / float(ln)) * ((float(f[i]) - 1.0f) / (float(ln - 1)));
	return IC;
}

float Substring::getMIC() {
	MIC = 0.0f;
	for (int i = 0; i < 26; ++i) {
		MIC += pbs[i] / 100.0f * (float(shF[i]) / float(ln));
	}
	return MIC;
}

void Substring::shift(int index) {
	index = index;
	shiftIndex = index;
	for (int i = 0; i < 26; ++i) shF[i] = 0;
	for (int i = 0; i < ln; ++i) {
		shiftedStr[i] = (str[i] - 'A' + index) % 26 + 'A';
		shF[shiftedStr[i] - 'A']++;
	}
	shiftedStr[ln] = 0;
}