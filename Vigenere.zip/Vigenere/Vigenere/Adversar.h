#pragma once
#include <string.h>
#include "Substring.h"

using namespace std;


class best {
	float medie_delta_IC = 1.0f, medie_delta_MIC=1.0f;
	//char * inv_key;
	char * key;
public:
	int max_m, m;
	char * inv_key;
	best(int max_m);
	void get(Substring * S, int m);
	char * get_key();
};

char * best::get_key() {
	for (int i = 0; i < m; ++i) {
		key[i] = (26 - (inv_key[i] - 'A') ) % 26 + 'A';
	}
	key[m] = 0;
	return key;
}

best::best(int max_m) {
	this->max_m = max_m;
	inv_key = new char[max_m + 1];
	memset(inv_key, 0, max_m);
	key = new char[max_m + 1];
	memset(key, 0, max_m);
}

void best::get(Substring * S, int m) {
	float m_d_IC2 = 0.0f;
	float m_d_MIC2 = 0.0f;

	for (int i = 0; i < m; ++i) {
		m_d_IC2 += abs (S[i].getIC() - 0.065f);
		m_d_MIC2 += abs(S[i].getMIC() - 0.065f);
	}

	m_d_IC2 /= float(m);
	m_d_MIC2 /= float(m);

	if ( m_d_IC2 + m_d_MIC2  < medie_delta_IC + medie_delta_MIC) {
		this->m = m;
		medie_delta_IC = m_d_IC2;
		medie_delta_MIC = m_d_MIC2;

		for (int i = 0; i < m; ++i) {
			inv_key[i] = (char)S[i].shiftIndex + 'A';
		}
		inv_key[m] = NULL;
	}
}

class Adversar {
private:
	char * criptoText;
	int max_m;
	//float best_delta = 1.0f;
	Substring * S;

public:
	int m;
	best* B;
	Adversar(char * a, int max_m);
	void cautare();
	
};

Adversar::Adversar(char * a, int max_m) {
	B = new best(max_m);
	this->max_m = max_m;
	S = new Substring[max_m];
	delete (criptoText);
	criptoText = new char[strlen(a) + 1];
	strcpy(criptoText, a);
}


void Adversar::cautare() {
	for (int i = 1; i <= max_m; ++i) {
		m = i;
		for (int j = 0; j < m; ++j) {
			S[j].set(this->criptoText, m, j);
			S[j].getIC();
			S[j].best_shift();
		}
		B->get(S, m);
	}
}