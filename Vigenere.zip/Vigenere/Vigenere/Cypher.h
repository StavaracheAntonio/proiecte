#pragma once
#include <string.h>

class Cypher {
public:
	char * key;
	int keyLength;
	Cypher(const char * key);
	Cypher(char * key);

	char * filtrare(char * a, char * b);
	char * criptare(char * a, char * b);

};

Cypher::Cypher(const char * key) {
	char *a = new char[strlen(key)+1];
	strcpy (a, (char*) key);
	this->key = filtrare(a, this->key);
	keyLength = strlen(this->key);

}

Cypher::Cypher(char * key) {
	char *a = new char[strlen(key)+1];
	strcpy(a, key);
	this ->key = filtrare(a, this->key);
	keyLength = strlen(this->key);
}

char * Cypher::filtrare(char * a, char * b) {
	if (a == NULL) {
		printf("nu am primit textul ce urmeaza a fi filtrat");
	}
	delete (b);
	b = new char[strlen(a)+1];
	unsigned int j = 0;
	for (unsigned int i = 0; i < strlen(a); ++i) {
		if (a[i] >= 'a' && a[i] <= 'z') {
			b[j] = a[i] - ('a' - 'A');
			j++;
		}

		if (a[i] >= 'A' && a[i] <= 'Z') {
			b[j] = a[i] ;
			j++;
		}
	}
	b[j] = NULL;
	return b;
}

char * Cypher::criptare( char * a, char * b) {

	if (a == NULL) {
		printf("nu am primit textul ce urmeaza a fi filtrat");
	}
	delete (b);
	b = new char[strlen(a) + 1];
	unsigned int i = 0;
	for (i = 0; i < strlen(a); ++i) {
		b[i] = (a[i] - 'A' + key[i % keyLength] - 'A') % 26 + 'A';
	}
	b[i] = NULL;
	return b;
}
