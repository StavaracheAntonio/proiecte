#include <Function.h>
#include "stdafx.h"

Six_hump::Six_hump(float a1, float b1, float bits_num1) {
	name = "Six_hump";
	dim = 2;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}


float Six_hump::eval(float * v) {
	float s = 0.0f;
	s = (4.0f - 2.1f * pow(v[0], 2.0f) + pow(v[0], 4.0f) / 3.0f);
	s *= (v[0] * v[0]);
	s += (v[0] * v[1]);
	s += ((-4.0f + 4.0f * pow(v[1], 2.0f)) * pow(v[1], 2.0f));
	return s;
}