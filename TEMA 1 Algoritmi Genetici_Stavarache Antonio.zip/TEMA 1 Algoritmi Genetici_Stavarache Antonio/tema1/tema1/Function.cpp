#include "stdafx.h"
#include "Function.h"
#include <stdio.h>

using namespace std;

struct evals {
	int nr, target;
	float best_value;
	
	void init(int n) {
		target = n;
		best_value = std::numeric_limits<float>::infinity();
		nr = 0;
	}
	
	void inc(float v) {
		nr++;
		if (best_value > v && nr <= target) {
			best_value = v;
		}
		//if (nr % 250 == 0 && nr <= target)
		//	printf("%f\n", best_value, nr);
	}

}E;

struct random_ij {
private:
	int x[32], y[32];
public:
	void init(int n, int m) {
		for (int i = 0; i < n; ++i)
			x[i] = i;
		for (int i = 0; i < m; ++i)
			y[i] = i;


		int l = rand() % (n * n);
		for (int k = 1; k <= l; ++k) {
			swap(x[rand() % n], x[rand() % n]);
		}

		l = rand() % (m * m);
		for (int k = 1; k <= l; ++k) {
			swap(y[rand() % m], y[rand() % m]);
		}

	}

	int get_i(int i) { return x[i]; }
	int get_j(int j) { return y[j]; }
} R;

void Function::presentation() {
	printf("%s on", name);
	printf(" %d dimensions, %d bits per dimension \n", dim, bits_num);
	printf("global optimum : %f\n\n", best);
}

void Function::StrBit_to_Float(int *v, float *w) {
	for (int i = 0; i < dim; ++i) {
		int k = 0, z= *(v+i);
		for (int j = 0; j < bits_num; ++j) {
			if (z & (1 << j)) {
				k += (1 << j);
			}
		}
		float x = lft + (rght - lft) * (float(k) / float(1<<bits_num));
		*(w + i) = x;
	}
}

void Function::bit_negation(int &n, int poz) {
	if (poz >= bits_num) {
		printf("eroare functia bit_negation");
	}
	else {
		if (n & (1 << poz)) {
			n = n & (~(1 << poz));
		}
		else {
			n = n | (1 << poz);
		}
	}
}

void Function::bit_random_negation(int &n) {
	int a = rand() % bits_num;
	bit_negation(n, a);
}

float rand_01() {
	return float (float( (rand() * rand()) % 1000000000) / 1000000000.0f);
}

void Function::set_rand_bits(int &n) {
	int a;
	n = 0;
	for (int i = 0; i < bits_num; ++i) {
		a = rand() % 2;
		if (a == 1)
			this->bit_negation(n, i);
	}
}

void Function::rand_init() {
	srand(time(NULL));
	for (int i = 1; i <= 1000000; ++i)
		rand();
}

void Function :: set_rand_vec(int * v) {
	for (int k = 0; k < dim; ++k)
		set_rand_bits(v[k]);
}

int Function :: get_first(int * v) {
	float w[100];
	for (int i = 0; i < dim; ++i) {
		for (int j = 0; j < bits_num; ++j) {
			bit_negation( v[ R.get_i(i) ], R.get_j(j) );
			StrBit_to_Float(v, w);
			
			if (eval(w) < best) {
				i = dim + 1;
				j = bits_num + 1;
				return 0;
			}
			else {
				bit_negation(v[R.get_i(i)], R.get_j(j));
			}
		}
	}
	return -1;
}

int Function::get_best(int * v) {
	float w[100];
	int i_min = 0, j_min = 0;
	float minim = std::numeric_limits<float>::infinity();;
	for (int i = 0; i < dim; ++i) {
		for (int j = 0; j < bits_num; ++j) {
			bit_negation( v[ R.get_i(i) ] , R.get_j (j) );
			StrBit_to_Float(v, w);
			float a = eval(w);

			if (a < minim) {
				i_min = R.get_i (i);
				j_min = R.get_j (j);
				minim = a;
			}
			bit_negation( v[ R.get_i ( i) ], R.get_j(j));
		}
	}
	if (minim < best) {
		bit_negation(v[i_min], j_min);
		return 0;
	}
	return -1;
}




void Function::Hill_Climbing_It(int num, int type) {

	best = std::numeric_limits<float>::infinity();
	int X2[100];

	R.init(dim, bits_num);

	for (int t = 1; t <= num; ++t) {
		best = std::numeric_limits<float>::infinity();
		bool found = true;
		this->set_rand_vec(X2);

		while (found) {
			found = false;
			int a;
			if (type % 2 == 0)
				a = get_best(X2);
			else
				a = get_first(X2);
			
			if (a == 0) {
				StrBit_to_Float(X2, sol);
				best = eval(sol);

				for (int i = 0; i < dim; ++i) {
					X[i] = X2[i];
				}

				found = true;
			}
		}

	}
	printf("Hill_Climbing ");
	if (type % 2 == 0)
		printf("best improvement \n");
	else
		printf("first improvement \n");
	presentation();

}


void int_cpy(int* a, int *b, size_t len){
	for (int i = 0; i < len; ++i)
		a[i] = b[i];
}

struct terminator {
	int x, y;
	bool termination_condition;

	void init( ) { x = 0; y = 0; termination_condition = false; }
	
	void iterate(int n, int m) {
		y++;
		x += (y / m);
		y %= m;
		if (x >= n)
			termination_condition = true;
	}

} Term;

void Function::Simulated_Annealing_It(int num) {

	best = std::numeric_limits<float>::infinity();
	int X1[100], X2[100];

	for (int t = 1; t <= num; ++t) {

		best = std::numeric_limits<float>::infinity();
		this->set_rand_vec(X1);
		float T = 10000.0f;

		while (T > 0.0000001f) {
			Term.init();
			R.init(dim, bits_num);

			while (Term.termination_condition == false) {
				int_cpy(X2, X1, dim);
				bit_negation(X2[R.get_i(Term.x)], R.get_j(Term.y));

				StrBit_to_Float(X1, sol);
				float a = eval(sol);
				StrBit_to_Float(X2, sol);
				float b = eval(sol);

				if (b < a) {
					if (best > b) {
						int_cpy(X2, X1, dim);
						int_cpy(X, X2, dim);
						best = b;
					}
					int_cpy(X1, X2, dim);
				}
				else {
					if (rand_01() < exp(-abs(b - a) / T))
						int_cpy(X1, X2, dim);
				}
				bit_negation(X2[R.get_i(Term.x)], R.get_j(Term.y));
				
				Term.iterate(dim, bits_num);
				T = T * 0.9999f;
			}
		}

	}
	//printf("%f\n", best);
	printf("Simulated Annealing \n");
	presentation();
}



Six_hump::Six_hump(float a1, float b1, float bits_num1) {
	name = "Six_hump";
	dim = 2;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}


float Six_hump::eval(float * v) {
	float s = 0.0f;
	s = (4.0f - 2.1f * pow(v[0], 2.0f) + pow(v[0], 4.0f) / 3.0f);
	s *= (v[0] * v[0]);
	s += (v[0] * v[1]);
	s += ((-4.0f + 4.0f * pow(v[1], 2.0f)) * pow(v[1], 2.0f));
	
	E.inc(s);
	return s;
}


DeJong :: DeJong(int dim1, float a1, float b1, int bits_num1) {
	name = "DeJong";
	dim = dim1;
	if (dim > 30)
		dim = 30;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}

float DeJong :: eval(float * v) {
	float s = 0.0f;
	for (int i = 0; i < dim; ++i) {
		s += (v[i] * v[i]);
	}

	E.inc(s);
	return s;
}

Rastrigin :: Rastrigin(int dim1, float a1, float b1, int bits_num1) {
	name = "Rastrigin";
	dim = dim1;
	if (dim > 30)
		dim = 30;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}

float Rastrigin::eval(float * v) {
	float s, x, t;
	s = dim * 10;
	for (int i = 0; i < dim; ++i) {
		s += (v[i] * v[i] - 10 * cos((2 * PI * v[i])));
	}

	E.inc(s);
	return s;
}

Schwefel ::Schwefel(int dim1, float a1, float b1, int bits_num1) {
	name = "Schwefel";
	dim = dim1;
	if (dim > 30)
		dim = 30;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}

float Schwefel :: eval(float * v) {
	float s = 0.0f;
	for (int i = 0; i < dim; ++i) {
		s += -v[i] * sin((sqrt(abs(v[i]))));
	}

	E.inc(s);
	return s;
 }