#pragma once
#include "stdafx.h"
#include <stdio.h>      
#include <stdlib.h> 
#include <time.h> 
#include <math.h>
#include <iostream>

#define PI 3.14159265

using namespace std;

class Function {

public:
	int dim;
	int bits_num;
	float lft, rght, best;
	int X[100];
	float sol[100];
	const char* name;

	virtual float eval(float *v)=NULL;


	void StrBit_to_Float(int *v, float* w);

	void bit_negation(int &n, int poz);
	static void rand_init();
	void bit_random_negation(int &n);

	void set_rand_bits(int &n);
	void set_rand_vec(int * v);
	
	int get_first(int * v);
	int get_best(int * v);

	void Hill_Climbing_It(int num, int type);
	void Simulated_Annealing_It(int num);

	void presentation();
};

class Six_hump : public Function {
public:
	Six_hump(float a1, float b1, float bits_num1);
	float eval(float * v);
};

class DeJong : public Function {
public:

	DeJong(int dim1, float a1, float b1, int bits_num1);
	float eval(float * v);
};

class Rastrigin : public Function {
public:

	Rastrigin(int dim1, float a1, float b1, int bits_num1);
	float eval(float * v);
};

class Schwefel : public Function {
public:

	Schwefel(int dim1, float a1, float b1, int bits_num1);
	float eval(float * v);
};
