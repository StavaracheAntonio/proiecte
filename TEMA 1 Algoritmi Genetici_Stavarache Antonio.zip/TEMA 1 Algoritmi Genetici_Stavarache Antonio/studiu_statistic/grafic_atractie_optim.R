HC_first = scan("sample1.txt")
HC_best = scan("sample2.txt")
SA = scan("sample3.txt")

nr_apeluri = seq( 0, 97500, 2500)

#plot(x, sample1, type = 'l', main='grafic', sub = 'subtilul', xlab ='axa x', ylab = 'axa y')
#plot(x, sample2, type = 'l', main='grafic', sub = 'subtilul', xlab ='axa x', ylab = 'axa y')

plot(x,sample1,type="l",col="red")
lines(x,sample2,col="green")

#plot(x, sample1, type = "l", col = "red")
#plot(x, sample2, type = "l", col = "green")

library(lattice)

xyplot(HC_first + HC_best + SA ~ nr_apeluri, ylab = "best", type = "l", auto.key = list(points = FALSE,lines = TRUE))


xyplot(HC_first + HC_best + SA ~ nr_apeluri ,ylab = "best", type = "l", auto.key = list(points = F,lines = T), par.settings = list(superpose.line = list(col = c("red","green", "blue"))))
