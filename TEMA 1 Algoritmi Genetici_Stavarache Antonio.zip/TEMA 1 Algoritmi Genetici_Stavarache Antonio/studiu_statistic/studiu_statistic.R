sample = scan("sample.txt")
minim = min(sample)
maxim = max(sample)
minim
maxim

medie = mean(sample)
deviatie_standard = sd (sample)

medie
deviatie_standard

