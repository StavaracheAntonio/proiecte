<?php

require __DIR__ . '/core/app.php';
require __DIR__ . '/core/controller.php';

$app = new App();

$app->run();
