<footer>
    <div class="footer-item">
        <h2>Our team</h2>
        <ul>
            <li>
                <h4>Acsinte Matei</h4>
                <h4>acsinte.matei.ionut@gmail.com</h4>
            </li>
            <li>
                <h4>Raducanu Andrei</h4>
                <h4>raducanu.andrei98@gmail.com</h4>
            </li>
            <li>
                <h4>Stavarache Antonio</h4>
                <h4>stavarache.antonio@gmail.com</h4>
            </li>
        </ul>
    </div>
    <div class="footer-item">
        <h2>Contact</h2>
        <a class="shadow" href="https://github.com/StavaracheAntonio/proiect-TW"><img src="/mvc/public/styles/img/icons/github.png" alt="github"></a>
    </div>
</footer>