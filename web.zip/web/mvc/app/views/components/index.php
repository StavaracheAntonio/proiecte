<div id="index-content">
    <h1><i>“Traveling – it leaves you speechless, <br>
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;then turns you into a storyteller.”</i></h1>
    <a class="shadow" href="home">TRAVEL NOW</a>
</div>