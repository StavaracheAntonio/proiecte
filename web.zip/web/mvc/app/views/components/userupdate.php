<form class="user-update-panel shadow" id="updateForm">
    <h2>Update password</h2>
    <input class="user-update-field shadow" type="password" id="update-password" placeholder="New Password">
    <input class="user-update-field shadow" type="password" id="update-cpassword" placeholder="Confirm password">
    <button class="shadow" type="submit">UPDATE</button>
</form>