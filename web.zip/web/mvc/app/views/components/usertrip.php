<div class="user-trip-panel shadow">
    <h2>Saved Flights</h2>
    <div id="user-trip-container">
    </div>
</div>