<div class="user-info-panel shadow">
    <img src="public/styles/img/icons/user.png" class="shadow" alt="user">
    <h2><?php echo $_SESSION["username"]  ?></h2>
    <h4><?php echo $_SESSION["email"]  ?></h4>
</div>