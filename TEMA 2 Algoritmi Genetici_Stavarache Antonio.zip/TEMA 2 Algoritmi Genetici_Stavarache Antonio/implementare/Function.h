﻿#pragma once
#include "stdafx.h"
#include <stdio.h>      
#include <stdlib.h> 
#include <time.h> 
#include <math.h>
#include <iostream>

#define PI 3.14159265

using namespace std;



class Cromozome {
public:
	int dim, bits_num;
	char * X;
	Cromozome(int dim1, int bits_num1);
	void cpy(Cromozome & C2);
	void cross(Cromozome & a);
	void mutation(float pm);
	~Cromozome();
};

class Function {

public:
	float C;
	float ev[40000], T, p[40000], q[40000];

	int dim;
	int bits_num;
	int E;

	int pop_size;
	float pc, pm;

	float lft, rght, best;
	
	Cromozome* V[40000];
	Cromozome* W[40000];

	float f(float a);
	void Evalueaza();
	void cross_over(float pc);

	void Genereaza();
	void Recombina();
	void Selecteaza();

	float sol[100];
	float x[100];

	const char* name;

	static void rand_init();
	static float rand_float_subunitar();
	void StrBit_to_Float(Cromozome *a, float *w);
	
	
	virtual float eval(float *v) = NULL;

	void calc();
};

class DeJong : public Function {
public:

	DeJong(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E);
	float eval(float * v);
};

class Six_hump : public Function {
public:
	Six_hump(float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E);
	float eval(float * v);
};

class Rastrigin : public Function {
public:
	Rastrigin(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E);
	float eval(float * v);
};

class Schwefel : public Function {
public:

	Schwefel(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E);
	float eval(float * v);
};