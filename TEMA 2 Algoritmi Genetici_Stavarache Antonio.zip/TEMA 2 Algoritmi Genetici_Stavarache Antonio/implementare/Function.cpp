#include "stdafx.h"
#include "Function.h"
#include <stdio.h>


void Function::rand_init() {
	srand(time(NULL));
	for (int i = 1; i <= 1000000; ++i)
		rand();
}

float Function::rand_float_subunitar()
{
	float x = (float(rand() % 32000 + 1) / 32000.0f) * (float(rand() % 32000 + 1) / 32000.0f);
	return x;
}

Cromozome :: Cromozome(int dim1, int bits_num1) {
	dim = dim1;
	bits_num = bits_num1;
	X = new char [dim1 * bits_num1 * sizeof(char)];
	for (int i = 0; i < dim * bits_num; ++i)
		X[i] = rand() % 2;
}

void Cromozome::cpy (Cromozome & C2) {
	dim = C2.dim;
	bits_num = C2.bits_num;
	for (int i = 0; i < dim * bits_num; ++i)
		X[i] = C2.X[i];
}

void Cromozome::cross( Cromozome & a) {
	int d = bits_num * dim;
	for (int i = 1 + (rand() % d - 1); i < d; ++i) 
		swap(this->X[i], a.X[i]);
}

void Function :: cross_over(float pc) {
	
	Cromozome* first = NULL, *last=NULL;
	int j;

	for (int i = 0; i < pop_size; ++i) {
		if (Function::rand_float_subunitar() < pc) {
			last = V[i];
			for (j = i+1; j < pop_size; ++j) {
				if (Function::rand_float_subunitar() < pc) {
					V[j]->cross( *V[i]);
					last = NULL;
					i = j + 1;
					j = pop_size+5;
				}
			}
			if( j< pop_size+3)
				i = pop_size;
		}
		else {
			if (first == NULL)
				first = V[i];
		}

		if (last && first && Function::rand_float_subunitar() < 0.5) {
			first->cross( *last);
		}
	}
}


void Cromozome :: mutation(float pm) {
	for (int i = 0; i < bits_num; ++i) {
		if (Function :: rand_float_subunitar() < pm) {
			if (X[i] == 1) X[i] = 0;
			else
				X[i] = 1;
		}
	}
}

void Function::Recombina() {
	cross_over(pc);
	for (int i = 0; i < pop_size; ++i)
		V[i]->mutation(pm);
}

Cromozome::~Cromozome() {
	delete (X);
}

void Function::Genereaza() {
	for (int i = 0; i < pop_size; ++i) {
		V[i] = new Cromozome(dim, bits_num);
		W[i] = new Cromozome(dim, bits_num);
	}
}

void Function::StrBit_to_Float(Cromozome *a, float *w) {
	for (int i = 0; i < dim; ++i) {
		int k = 0;
		for (int j = 0; j < bits_num; ++j) 
			if ( (a->X[i*bits_num+j]) !=0)
				k += (1 << j);
		float x = lft + (rght - lft) * (float(k) / float(1 << bits_num));
		*(w + i) = x;
	}
}

float Function :: f(float a) {
	return float((1 / ( 2* abs(best)+ a)));
}

void Function::Evalueaza() {
	//evalueaza populatie
	for (int i = 0; i < pop_size; ++i) {
		StrBit_to_Float(V[i], x);
		ev[i] = f(eval(x));
	}

	//fitnessul total
	T = 0;
	for (int i = 0; i < pop_size; ++i) {
		T += ev[i];
	}

	//PROB.SEL.INDIVIDUALE
	for (int i = 0; i < pop_size; ++i)
		p[i] = ev[i] / T;

	//PROB.SEL.CUMULATE
	q[0] = 0;
	for (int i = 0; i < pop_size - 1; ++i)
	{
		q[i + 1] = q[i] + p[i];
	}
	q[pop_size-1] = 1;
}


void Function::Selecteaza() {
	for (int i = 0; i < pop_size; ++i) {
		float r = rand_float_subunitar();
		int j = 0;
		while (q[j] < r ) {
			j++;
		}
		W[i]->cpy( *V[j-1]);
	}

	for (int i = 0; i < pop_size; ++i) {
		V[i]->cpy( *W[i]);
	}
}

void Function::calc() {
	int t = 0;
	float global_best = 100000000.0f;
	for (int k = 0; k < E; ++k) {
		best = 10000000.0f;
		Genereaza();
		Evalueaza();
		for (t = 0; t <= 100; ++t) {
			Selecteaza();
			Recombina();
			Evalueaza();
		}
		if (global_best > best)
			global_best = best;
	}
	best = global_best;
}

DeJong::DeJong(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E) {
	pop_size = pop_size1;
	pc = pc1;
	this->E = E;
	pm = pm1;

	name = "DeJong";
	dim = dim1;
	
	if (dim > 30)
		dim = 30;

	best = 100000;
	C = 10;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}


float DeJong::eval(float * v) {
	float s = 0.0f;
	for (int i = 0; i < dim; ++i) {
		s += (v[i] * v[i]);
	}
	if (s < best) {
		best = s;
	}
	return s;
}

Six_hump::Six_hump(float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E) {
	pop_size = pop_size1;
	pc = pc1;
	this->E = E;
	pm = pm1;

	name = "Six_hump";
	dim = 2;

	best = 100000;
	C = 10;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}


float Six_hump::eval(float * v) {
	float s = 0.0f;
	s = (4.0f - 2.1f * pow(v[0], 2.0f) + pow(v[0], 4.0f) / 3.0f);
	s *= (v[0] * v[0]);
	s += (v[0] * v[1]);
	s += ((-4.0f + 4.0f * pow(v[1], 2.0f)) * pow(v[1], 2.0f));

	if (s < best) {
		best = s;
	}

	return s;
}

Rastrigin::Rastrigin(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E) {
	pop_size = pop_size1;
	this->E = E;
	pc = pc1;
	pm = pm1;

	name = "Rastrigin";
	dim = dim1;

	if (dim > 30)
		dim = 30;

	best = 100000;
	C = 10;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}


float Rastrigin::eval(float * v) {
	float s, x, t;
	s = dim * 10;
	for (int i = 0; i < dim; ++i) {
		s += (v[i] * v[i] - 10 * cos((2 * PI * v[i])));
	}
	if (s < best) {
		best = s;
	}
	return s;
}

Schwefel::Schwefel(int dim1, float a1, float b1, int bits_num1, int pop_size1, float pc1, float pm1, int E) {
	pop_size = pop_size1;
	this->E = E;
	pc = pc1;
	pm = pm1;

	name = "Schwefel";
	dim = dim1;
	if (dim > 30)
		dim = 30;

	best = 100000;
	C = 10;
	lft = a1;
	rght = b1;
	bits_num = bits_num1;
	if (bits_num > 30)
		bits_num = 30;
}

float Schwefel::eval(float * v) {
	float s = 0.0f;
	for (int i = 0; i < dim; ++i) {
		s += -v[i] * sin((sqrt(abs(v[i]))));
	}

	if (s < best) {
		best = s;
	}
	
	return s;
}