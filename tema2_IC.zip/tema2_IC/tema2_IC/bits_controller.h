#pragma once
#include <iostream>

using namespace std;


class bits_controller {

public:
	void erase(unsigned long long & x) {
		x = x << 60;
		x = x << 60;
	}

	void set_bit(unsigned long long & x, int poz, int val) {
		if (val > 0) val = 1;
		if (poz > 63) poz = poz % 64;
		long long i = val;
		if (i == 1)
			x = x | (i << poz);
		else
			x = x & ( ( ~((unsigned long long) 0)) ^ long long (1) << poz);
	}

	int get_bit(unsigned long long x, int poz) {
		if (poz > 63) poz = poz % 64;
		unsigned long long i = 1;
		i = i << poz;
		if ((x & i) != 0)
			return 1;
		else
			return 0;
	}

	unsigned long long apply_perm2 (int* perm, int len, int len2, unsigned long long x) {
		unsigned long long a;
		erase(a);
		for (int i = 0; i < len; ++i) {
			set_bit(a, len - i - 1, get_bit(x, len2 - perm[i] ));
		}
		return a;
	}

	unsigned long long apply_inv_perm (int* perm, int len, int len2, unsigned long long x) {
		unsigned long long a;
			int q, w;
		erase(a);
		for (int i = 0; i < len; ++i) {
			q = len - perm[i];
			w = get_bit(x, len - i - 1);
			set_bit(a, q, w);
		}
		return a;
	}

	void LS(unsigned long long & x, int i) {
		if (i != 1 && i != 2 && i != 9 && i != 16)
			LS(x, 1);
		unsigned long long a;
		erase(a);
		a = get_bit(x, 27);
		set_bit(x, 27, 0);
		x = x << 1;
		x = x + a;
	}
};