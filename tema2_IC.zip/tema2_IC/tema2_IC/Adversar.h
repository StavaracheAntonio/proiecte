#pragma once
#include "DES.h"

class Adversar {
public:
	struct k {
		unsigned long long a;
		unsigned long long b;
	};
	k K[256], res;

	unsigned long long plain_text, cripto_text;
	DES* D;
	Adversar(unsigned long long plain_text, unsigned long long cripto_text, DES * A);
	void meetInTheMidle();

private:
	int bin_search(k* K, int l, int r, k b_in);
};