#include "pch.h"
#include "DES.h"
#include <string.h>
#include <fstream>
#include <iostream>
#include "bits_controller.h"
#include "string.h"


using namespace std;

DES::DES(char * input_file, char* key) {
	citire ( input_file);
	setKey(key);
	setKeys();
}

DES::DES(char * input_file, unsigned long long key) {
	citire(input_file);
	this->key = key;
	setKeys();
}

char * DES::encrypt(char * plainText) {
	unsigned int l = strlen(plainText) /8 *8;
	char * a = new char[l+1];

	memset(a, NULL, l + 1);

	for (unsigned int i = 0; i + 8 <= l; i += 8) {

		unsigned long long b = * (unsigned long long *) ( (plainText + i));
		unsigned long long x = encrypt( b );
		
		char q[10];
		strncpy( q , (char*)(&x), 8);
		
		strncpy(a+i , q, 8);
	}
	a[l] = 0;
	return a;
}
char * DES::decrypt(char * cryptoText) {
	unsigned int l = strlen(cryptoText) / 8 * 8;
	char * a = new char[l + 1];

	memset(a, NULL, l + 1);

	for (unsigned int i = 0; i + 8 <= l; i += 8) {

		unsigned long long b = *(unsigned long long *) (cryptoText + i);
		unsigned long long x = decrypt(b);

		char q[10];
		strncpy(q, (char*)(&x), 8);
		strncpy(a + i, q, 8);
	}
	a[l] = 0;
	return a;
}


unsigned long long DES::decrypt(unsigned long long t) {
	unsigned long long l, r, l_i, r_i;

	t = B.apply_perm2(IP, 64, 64, t);

	l = t >> 32;
	r = t % (unu << 32);

	for (int i = 16; i >= 1; --i) {

		l_i = r;
		r_i = (l ^ f(r, i));
		l = l_i;
		r = r_i;
	}
	t = r << 32;
	t = t + l;

	t = B.apply_inv_perm(IP, 64, 64, t);

	return t;
}

unsigned long long DES::encrypt(unsigned long long t) {
	unsigned long long l, r, l_i, r_i;

	t = B.apply_perm2(IP, 64, 64, t);

	l = t >> 32;
	r = t % ( unu << 32);

	for (int i = 1; i <= 16; ++i) {
		
		l_i = r;
		r_i = (l ^ f(r, i));
		l = l_i;
		r = r_i;
	}
	t = r << 32;
	t = t + l;

	t = B.apply_inv_perm(IP, 64, 64, t);

	return t;
}

unsigned long long DES::f(unsigned long long x, int i) {
	unsigned long long boxes[9], c[9];
	unsigned long long r = B.apply_perm2(E, 48, 32, x);


	r = (r ^ keys[i]);

	for (int j = 8; j > 0; --j) {
		boxes[j] = r %  (unu << 6);
		r = r >> 6;
		c[j] = get_S(boxes[j], j);
	}

	B.erase(r);
	for (int j = 1; j <= 8; ++j) {
		r = r << 4;
		r = r | c[j];
	}

	r = B.apply_perm2(P, 32, 32, r);

	return r;

}

unsigned long long DES :: get_S(unsigned long long a, int i) {
	long long x = B.get_bit(a, 5) * 2 + B.get_bit(a, 0);
	long long y = (a % (unu<< 5)) / 2;
	return S[i][x][y];
}

void DES::setKeys() {
	keys = new unsigned long long[17];
	unsigned long long r, c, d;
	B.erase(c);
	B.erase(d);
	r = B.apply_perm2 (PC1, 56, 64,  key);

	d = r % (1 << 28);
	c = r >> 28;

	for (int i = 1; i <= 16; ++i) {

		B.LS(c, i);
		B.LS(d, i);
		B.erase(r);
		
		r = (c << 28) | d % ( unu << 28);
		
		B.erase(keys[i]);
		keys[i] = B.apply_perm2(PC2, 48, 56, r);
	}
}

void DES::setKey(char * s) {
	B.erase(key);
	unsigned long long j;
	int n = strlen(s);
	for (int i = 0; i < n; ++i) {
		j = 0;
		if (s[i] <= '9' && s[i] >= '0')
			j = s[i] - '0';
		if (s[i] <= 'F' && s[i] >= 'A')
			j = s[i] - 'A' + 10;
		key = key << 4;
		key += j;
	}
}

void DES::citire(char * input_file) {

	ifstream fin(input_file);
	
	char * empty_line = new char[300];

	for (int i =0; i<3; ++i)
		fin.getline(empty_line, 200);

	delete (IP);
	IP = new int[64];
	for (int i = 0; i < 64; ++i) {
		fin >> IP[i];
		fin.get();
	}

	fin.getline(empty_line, 200);
	fin.getline(empty_line, 200);

	delete(E);
	E = new int[48];
	for (int i = 0; i < 48; ++i) {
		fin >> E[i];
		fin.get();
	}


	for (int i = 1; i <= 8; ++i) {
		fin.getline(empty_line, 200);
		fin.getline(empty_line, 200);
		for (int m = 0; m < 4; ++m) {
			for (int n = 0; n < 16; ++n) {
				fin >> S[i][m][n];
				fin.get();
			}
		}
	}

	fin.getline(empty_line, 200);
	fin.getline(empty_line, 200);
	delete (P);
	P = new int[32];

	for (int i = 0; i < 32; ++i) {
		fin >> P[i];
		fin.get();
	}

	fin.getline(empty_line, 200);
	fin.getline(empty_line, 200);
	delete (PC1);
	PC1 = new int[56];

	for (int i = 0; i < 56; ++i) {
		fin >> PC1[i];
		fin.get();
	}

	fin.getline(empty_line, 200);
	fin.getline(empty_line, 200);
	delete (PC2);
	PC2 = new int[48];

	for (int i = 0; i < 48; ++i) {
		fin >> PC2[i];
		fin.get();
	}

	fin.close();

}