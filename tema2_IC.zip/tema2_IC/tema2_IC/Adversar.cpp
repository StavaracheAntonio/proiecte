#include "pch.h"
#include "DES.h"
#include <string.h>
#include <fstream>
#include <iostream>
#include "bits_controller.h"
#include "string.h"
#include "DES.h"
#include "Adversar.h"
#include <stdlib.h>

using namespace std;

struct k {
	unsigned long long a;
	unsigned long long b;
};

int compare(const void* per1, const void* per2);

Adversar::Adversar(unsigned long long plain_text, unsigned long long cripto_text, DES * A) {
	this->plain_text = plain_text;
	this->cripto_text = cripto_text;
	D = A;
}

void Adversar::meetInTheMidle() {
	res.a = 256;
	res.b = 256;

	for (unsigned long long i = 0; i <= 255; ++i) {
		K[i].a = i;
		D->key = i;
		D->setKeys();
		K[i].b = D->encrypt(plain_text);
	}

	qsort( K, 256, sizeof(*K), compare);

	k A;
	for (int i = 0; i <= 255; ++i) {
		D->key = i;
		D->setKeys();
		A.a = i;
		A.b = D->decrypt(cripto_text);
		int m;
		if ( (m = bin_search(K, 0, 255, A)) != -1) {
			res.a = K[m].a;
			res.b = A.a;
		}
	}

}

int Adversar::bin_search(k* K, int l, int r, k b_in) {
	//cout << b_in.a << "?????" << b_in.b << '\n';
	
	if (r >= l) {
		int m = l + (r - l) / 2;
		int comp = compare(  & K[m], &b_in);
		if (comp == 0) {
			return m;
		}
		else if (comp == 1) {
			return bin_search( K, l, m - 1, b_in);
		}
		else {
			return bin_search( K, m + 1, r, b_in);
		}

	}
	return -1;
}

int compare (const void* per1, const void* per2) {
	k p1 = *((k*)per1);
	k p2 = *((k*)per2);

	if (p1.b < p2.b) {
		return -1;
	}
	else if (p1.b > p2.b){
		return 1;
	}
	return 0;
}