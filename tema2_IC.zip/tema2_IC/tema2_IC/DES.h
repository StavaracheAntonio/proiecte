#pragma once
#include "pch.h"
#include <fstream>
#include "bits_controller.h"

using namespace std;

class DES {
public:
	unsigned long long key;
	unsigned long long* keys;
	unsigned long long S[9][4][16];
	const unsigned long long unu = 1;
	int* IP;
	int * E;
	int * P;
	int* PC1;
	int* PC2;

	bits_controller B;

	void citire(char * input_file);
	void setKeys();
	void setKey(char * s);

	char * decrypt(char * plainText);
	char * encrypt(char * cryptoText);
	
	DES(char * input_file, char * key);
	DES(char * input_file, unsigned long long key);
	unsigned long long encrypt(unsigned long long t);
	unsigned long long decrypt(unsigned long long t);
	unsigned long long f(unsigned long long x, int i);
	unsigned long long get_S(unsigned long long a, int i);
};