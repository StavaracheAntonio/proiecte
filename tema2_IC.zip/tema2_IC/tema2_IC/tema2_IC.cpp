// tema2_IC.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "DES.h"
#include "Adversar.h"

int main()
{

	DES *A = new DES ( (char *) ("boxes.txt"), (char*) "133457799BBCDFF1");

	unsigned long long a = 0x0123456789ABCDEF;
	unsigned long long b = A->encrypt(a);
	printf("%llx\n", b);
	a = A->decrypt(b);
	printf("%llx\n", a);

	unsigned long long t = 0x065645678900BCAC; 
	unsigned long long k1 = 0x0000000000000EE;
	unsigned long long k2 = 0x00000000000005F;
	A->key = k1;
	A->setKeys();
	unsigned long long c = A->encrypt(t);
	
	A->key = k2;
	A->setKeys();
	c = A->encrypt(c);

	Adversar* adv = new Adversar(t, c, A);

	adv->meetInTheMidle();
	printf("%llx %llx", adv->res.a, adv->res.b);
}