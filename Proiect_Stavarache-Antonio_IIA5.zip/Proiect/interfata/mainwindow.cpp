#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <iostream>
/* codul de eroare returnat de anumite apeluri */
extern int errno;

using namespace std;

/* portul de conectare la server*/
int port;
int sd;			// descriptorul de socket


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    void input_ruta(char * ruta);
    void input_nume(char * nume);
    void intput_intarziere(int & a);
    struct sockaddr_in server;	// structura folosita pentru conectare
                                    // mesajul trimis
    int size, command, nr = 0;
    char chr;
    char buf[10], route[200], ruta[100], nume[100];

    int status;
    int intarziere;
    char adresaIp[31];
    strcpy(adresaIp,"127.0.0.1");
    port=4055;

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        perror("Eroare la socket().\n");
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(adresaIp);
    server.sin_port = htons(port);

    if (::connect(sd, (struct sockaddr *) &server, sizeof(struct sockaddr)) == -1){
        perror("[client]Eroare la connect().\n");
    }
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    ::close(sd);
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    int command=1;
    if (write(sd, &command, sizeof(int)) <= 0){
        perror("[client]Eroare la write() spre server.\n");
        return ;
    }

    char nume[201],route[2048],result[256];
    int size;
    bzero(route,2048);
    memset(nume, 0, 100);
    strcpy(nume,ui->lineEdit->text().toLatin1().data());
    int l = strlen(nume);

    if (write(sd, &l, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    else {
        if (write(sd, nume, l) <= 0){
            perror("Eroare la write() spre server.\n");
        }
    }
    if (read(sd, &size, sizeof(int)) < 0){
       perror("[client]Eroare la read() de la server.\n");
       return;
    }


   for (int i = 1; i <= size; ++i){
       if (read(sd, &l, sizeof(int)) < 0){
           perror("[client]Eroare la read() de la server.\n");
           return ;
       }
       bzero(result,256);
       if (read(sd, result, l) < 0)
       {
           perror("[client]Eroare la read() de la server.\n");
           return ;
       }

       strcat(route,result);
   }
   ui->textBrowser->setText(QString::fromLocal8Bit(route));
}

void MainWindow::on_butonPlecari_clicked()
{
    int command=2;
    if (write(sd, &command, sizeof(int)) <= 0){
        perror("[client]Eroare la write() spre server.\n");
        return ;
    }

    char nume[201],route[2048],result[256];
    int size;
    bzero(route,2048);
    memset(nume, 0, 100);
    strcpy(nume,ui->lineEdit_2->text().toLatin1().data());
    int l = strlen(nume);
    if (write(sd, &l, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    else {
        if (write(sd, nume, l) <= 0){
            perror("Eroare la write() spre server.\n");
        }
    }
   if (read(sd, &size, sizeof(int)) < 0){
       perror("[client]Eroare la read() de la server.\n");
        return;
   }

   for (int i = 1; i <= size; ++i){
       if (read(sd, &l, sizeof(int)) < 0){
           perror("[client]Eroare la read() de la server.\n");
           return ;
       }
       bzero(result,256);
       if (read(sd, result, l) < 0){
           perror("[client]Eroare la read() de la server.\n");
           return ;
       }
       strcat(route,result);
   }
   ui->textBrowser->setText(QString::fromLocal8Bit(route));
}

void MainWindow::on_butonInformatiiRuta_clicked()
{
    int command=3;
    if (write(sd, &command, sizeof(int)) <= 0){
        perror("[client]Eroare la write() spre server.\n");
        return ;
    }
    char ruta[201], route[2048], result[256];
    int size;
    bzero(route, 2048);

    memset(ruta, 0, 100);
    strcpy(ruta,ui->lineEdit_3->text().toLatin1().data());
    int l = strlen(ruta);

    if (write(sd, &l, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    else {
        if (write(sd, ruta, l) <= 0){
            perror("Eroare la write() spre server.\n");
        }
    }
    if (read(sd, &size, sizeof(int)) < 0){
        perror("[client]Eroare la read() de la server.\n");
        return;
    }
    for (int i = 1; i <= size; ++i){
        if (read(sd, &l, sizeof(int)) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        bzero(result,256);
        if (read(sd, result, l) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        strcat(route,result);
    }
    ui->textBrowser->setText(QString::fromLocal8Bit(route));
}

void MainWindow::on_butonSemnalareIntarziere_clicked()
{
    int command=4;
    if (write(sd, &command, sizeof(int)) <= 0){
        perror("[client]Eroare la write() spre server.\n");
        return ;
    }
    char ruta[201],route[2048],result[256],nume[201];
    int size;
    bzero(route,2048);

    memset(nume, 0, 100);
    strcpy(nume,ui->lineEdit_4->text().toLatin1().data());
    int l = strlen(nume);

    if (write(sd, &l, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    else {
        if (write(sd, nume, l) <= 0){
            perror("Eroare la write() spre server.\n");
        }
    }

    memset(ruta, 0, 100);
    strcpy(ruta,ui->lineEdit_5->text().toLatin1().data());
    l = strlen(ruta);

    if (write(sd, &l, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    else {
        if (write(sd, ruta, l) <= 0){
            perror("Eroare la write() spre server.\n");
        }
    }
    char b[10];
    strcpy(b,ui->lineEdit_6->text().toLatin1().data());
    int a = atoi ( b);

    if (write(sd, &a, sizeof(int)) <= 0){
        perror("Eroare la write() spre server.\n");
    }
    if (read(sd, &size, sizeof(int)) < 0){
        perror("[client]Eroare la read() de la server.\n");
        return;
    }
    for (int i = 1; i <= size; ++i)
    {
        if (read(sd, &l, sizeof(int)) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        bzero(result,256);
        if (read(sd, result, l) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        strcat(route,result);
    }
    ui->textBrowser->setText(QString::fromLocal8Bit(route));
}

void MainWindow::on_butonToateRutele_clicked()
{
    int command=0,size,l;
    char result[256],route[6000];
    bzero(route,6000);
    if (write(sd, &command, sizeof(int)) <= 0){
        perror("[client]Eroare la write() spre server.\n");
        return ;
    }
    if (read(sd, &size, sizeof(int)) < 0){
        perror("[client]Eroare la read() de la server.\n");
        return ;
    }
    for (int i = 1; i <= size; ++i)
    {
        if (read(sd, &l, sizeof(int)) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        bzero(result,256);
        if (read(sd, result, l) < 0){
            perror("[client]Eroare la read() de la server.\n");
            return ;
        }
        strcat(route,result);
    }
    ui->textBrowser->setText(QString::fromLocal8Bit(route));
}
