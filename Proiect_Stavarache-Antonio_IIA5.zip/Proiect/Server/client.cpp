#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <string.h>
#include <arpa/inet.h>
#include <iostream>
/* codul de eroare returnat de anumite apeluri */
extern int errno;

using namespace std;

/* portul de conectare la server*/
int port;
int sd;			// descriptorul de socket
void input_ruta(char * ruta);
void input_nume(char * nume);
void intput_intarziere(int & a);

int main(int argc, char *argv[])
{
	struct sockaddr_in server;	// structura folosita pentru conectare 
								// mesajul trimis
	int fromTime, toTime, size, command, nr = 0;
	char chr;
	char buf[10], route[200], ruta[100], nume[100];

	int status;
	int intarziere;

	/* exista toate argumentele in linia de comanda? */
	if (argc != 3)
	{
		printf("Sintaxa: %s <adresa_server> <port>\n", argv[0]);
		return -1;
	}

	// stabilim portul 
	port = atoi(argv[2]);

	// cream socketul 
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("Eroare la socket().\n");
		return errno;
	}

	// umplem structura folosita pentru realizarea conexiunii cu serverul 
	// familia socket-ului 
	server.sin_family = AF_INET;
	// adresa IP a serverului 
	server.sin_addr.s_addr = inet_addr(argv[1]);
	// portul de conectare 
	server.sin_port = htons(port);

	// ne conectam la server 
	if (connect(sd, (struct sockaddr *) &server, sizeof(struct sockaddr)) == -1)
	{
		perror("[client]Eroare la connect().\n");
		return errno;
	}

	while(1)
	{
		command = -1;
		printf("\nIntroduceti comanda: ");
		fflush (stdout);
		printf("\n 0 Toate rutele \n 1 Sosiri in urmatoarea ora \n 2 Plecari in urmatoarea ora \n 3 Informatii ruta \n 4 Semnalati intarziere \n");
		fflush (stdout);

		scanf("%d", &command);
		printf("comanda : %d\n", command);fflush(stdout);

		if (write(sd, &command, sizeof(int)) <= 0){
			perror("[client]Eroare la write() spre server.\n");
			return errno;
		}

		switch (command){
			case 0:{
				break;
			}
			case 1:{
				input_nume(nume);
				break;
			}
			case 2:{
				input_nume(nume);
				break;
			}
			case 3:{
				input_ruta(ruta);
				break;
			}
			case 4:{
				input_nume(nume);
				input_ruta(ruta);
				intput_intarziere(intarziere);
				break;
			}
			default:{
				printf("Nu recunosc aceasta comanda.\n");
				fflush (stdout);
				break;
			}

		}

		// citirea raspunsului dat de server
		//(apel blocant pana cind serverul raspunde) 
		if (read(sd, &size, sizeof(int)) < 0)
		{
			perror("[client]Eroare la read() de la server.\n");
			return errno;
		}

		int l;

		printf("Size: %d\n", size);
		for (int i = 1; i <= size; ++i)
		{
			if (read(sd, &l, sizeof(int)) < 0){
				perror("[client]Eroare la read() de la server.\n");
				return errno;
			}

			printf("%d:\n", l);
			fflush (stdout);

			if (read(sd, route, l) < 0)
			{
				perror("[client]Eroare la read() de la server.\n");
				return errno;
			}

			printf("%s\n", route);
			fflush(stdout);
		}
		printf("am iesit \n");
		fflush(stdout);
	}
	//afisam mesajul primit 
	printf("[client]Mesajul primit este: %d\n", nr);

	// inchidem conexiunea, am terminat 
	close(sd);
}

void input_nume(char * nume){
	memset(nume, 0, 100);
	printf("Introduceti numele statiei\n");
	fflush(stdout);
	scanf("%s", nume);
	int l = strlen(nume);

	if (write(sd, &l, sizeof(int)) <= 0){
		perror("Eroare la write() spre server.\n");
	}
	else {
		if (write(sd, nume, l) <= 0){
			perror("Eroare la write() spre server.\n");
		}
	}
}

void input_ruta(char * ruta){
	memset(ruta, 0, 100);
	printf("Introduceti numele rutei\n");
	fflush(stdout);
	//scanf("%s\n", ruta);
	cin.getline (ruta, 100);
	cin.getline(ruta, 100);

	//fgets (ruta, 100, stdin);
	int l = strlen(ruta);

	if (write(sd, &l, sizeof(int)) <= 0){
		perror("Eroare la write() spre server.\n");
	}
	else {
		if (write(sd, ruta, l) <= 0){
			perror("Eroare la write() spre server.\n");
		}
	}
}

void intput_intarziere(int & a){
	printf("Introduceti intevalul de timp (in minute).\n");
	fflush(stdout);
	char b[10];
	//scanf("%s\n", ruta);
	cin.getline (b, 100);
	//cin.getline(b, 100);
	a = atoi ( b);
	printf("am citit%d\n\n\n", a); 

	if (write(sd, &a, sizeof(int)) <= 0){
		perror("Eroare la write() spre server.\n");
	}
}