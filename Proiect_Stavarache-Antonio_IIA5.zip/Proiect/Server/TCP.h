#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <time.h>
#include "command.h"

/* portul folosit */
#define PORT 4055

using namespace std;

CommQueue comQ;

Command* clientAnswer(struct thData tdL);
void input_commandType(struct thData tdL, Statie* S, int & command);
void input_Statie_nume(struct thData tdL, Statie* S);
void input_Statie_ruta(struct thData tdL, Statie* S);
void input_Statie_intarziere(struct thData tdL, Statie* S);

static void *treat(void * arg){
	struct thData tdL;
	tdL = *((struct thData*)arg);
	fflush(stdout);
	pthread_detach(pthread_self());

	while (1){
		Command* r = clientAnswer (tdL);
		if (r!= NULL){	
			while (r->A.done == false){
			}
			r->answer();
			delete(r);
		}
		else{
			close((intptr_t)arg);
			return(NULL);
		}
	}
};


static void *update(void * arg){
	pthread_detach(pthread_self());
	
	while(1){
		comQ.refresh();
	}
	return(NULL);
}

class TCP{
public:
	struct sockaddr_in server;	// structura folosita de server
	struct sockaddr_in from;
	int nr;		//mesajul primit de trimis la client 
	int sd;		//descriptorul de socket 
	int pid;
	pthread_t th[100], Up;    //Identificatorii thread-urilor care se vor crea
	int i;

	TCP();

	void Start();
};

TCP::TCP(){
	i=0;
	/* crearea unui socket */
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("[server]Eroare la socket().\n");
		exit(errno);
	}
	
	/* utilizarea optiunii SO_REUSEADDR */
	int on = 1;
	setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

	/* pregatirea structurilor de date */
	bzero(&server, sizeof(server));
	bzero(&from, sizeof(from));
	
	/* umplem structura folosita de server */
	/* stabilirea familiei de socket-uri */
	server.sin_family = AF_INET;
	/* acceptam orice adresa */
	server.sin_addr.s_addr = htonl(INADDR_ANY);
	/* utilizam un port utilizator */
	server.sin_port = htons(PORT);	
}

void TCP::Start(){
	/* atasam socketul */
	if (bind(sd, (struct sockaddr *) &server, sizeof(struct sockaddr)) == -1){
		perror("[server]Eroare la bind().\n");
		exit(errno);
	}

	/* punem serverul sa asculte daca vin clienti sa se conecteze */
	if (listen(sd, 2) == -1){
		perror("[server]Eroare la listen().\n");
		exit(errno);
	}

	pthread_create(& Up, NULL, &update, NULL);
	
	/* servim in mod concurent clientii...folosind thread-uri */
	while (1){
		
		int client;
		ThreadData * td; //parametru functia executata de thread     
		unsigned int length = sizeof(from);

		printf("[server]Asteptam la portul %d...\n", PORT);
		fflush(stdout);

		//client= malloc(sizeof(int));
		/* acceptam un client (stare blocanta pina la realizarea conexiunii) */
		if ((client = accept(sd, (struct sockaddr *) &from, &length)) < 0){
			perror("[server]Eroare la accept().\n");
			continue;
		}

		/* s-a realizat conexiunea, se astepta mesajul */
		int idThread; //id-ul threadului
		int cl; //descriptorul intors de accept

		td = (struct thData*)malloc(sizeof(struct thData));
		td->idThread = i++;
		td->cl = client;

		pthread_create(&th[i], NULL, &treat, td);

	}//while    
}

Command* clientAnswer(struct thData tdL){

	int c = 1;
	//while (1){

		int command=-1;
		Statie S;
		
		input_commandType(tdL, & S, command);


		switch (command){
			
			case 0:{
				return comQ.push_back( command, & tdL, & S);
				break;
			}
			case 1:{
				input_Statie_nume(tdL, &S);
				return comQ.push_back( command, & tdL, &S);
				break;
			}
			case 2:{
				input_Statie_nume(tdL, &S);
				return comQ.push_back( command, & tdL, &S);
				break;
			}
			case 3:{
				input_Statie_ruta(tdL, &S);
				comQ.push_back( command, & tdL, &S);
				break;
			}
			case 4:{
				input_Statie_nume(tdL, &S);
				input_Statie_ruta(tdL, &S);
				input_Statie_intarziere(tdL, &S);
				return comQ.push_back( command, & tdL, &S);
				break;	
			}
			default: 
				return NULL;
			break;
		}
	//}
}

void input_commandType(struct thData tdL, Statie* S, int & command){
	if (read(tdL.cl, &command, sizeof(int)) < 0){
		printf("[Thread %d]\n", tdL.idThread); fflush (stdout);
		perror("Eroare la read() a comenzii de la client.\n");
	}
	//else printf("Am primit comanda %d\n", command);

}

void input_Statie_nume(struct thData tdL, Statie* S){
	int l;
	if (read(tdL.cl, &l, sizeof(int)) < 0){
		printf("[Thread %d]\n", tdL.idThread);
		perror("Eroare la read() a comandei de la client.\n");
	}

	if (read(tdL.cl, S->nume, l) < 0){
		printf("[Thread %d]\n", tdL.idThread);
		perror("Eroare la read() de la client.\n");
	}
	//else printf("Statia aleasa %s\n", S->nume);
}

void input_Statie_ruta(struct thData tdL, Statie* S){

	memset(S->ruta, 0, 100);
	int l;
	if (read(tdL.cl, &l, sizeof(int)) < 0){
		printf("[Thread %d]\n", tdL.idThread);
		perror("Eroare la read() a comandei de la client.\n");
	}

	if (read(tdL.cl, S->ruta, l) < 0){
		printf("[Thread %d]\n", tdL.idThread);
		perror("Eroare la read() de la client.\n");
	}
	//else printf("Ruta aleasa %s\n", S->ruta);
}

void input_Statie_intarziere(struct thData tdL, Statie* S){
	if (read(tdL.cl, &S->intarziere, sizeof(int)) <= 0){
		printf("[Thread %d]\n", tdL.idThread);
		perror("Eroare la read() de la client.\n");
	}
	//else printf("intarziere: %d\n", S->intarziere);
}