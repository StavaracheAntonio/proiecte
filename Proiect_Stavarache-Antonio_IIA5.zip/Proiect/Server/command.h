#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <time.h>

#define DATA_BASE "MersulTrenurilor.xml"

using namespace std;


struct Statie {
	char ruta[100];
	char nume[50];
	int sosire, plecare;
	int intarziere;
};

typedef struct thData {
	int idThread; //id-ul thread-ului tinut in evidenta de acest program
	int cl; //descriptorul intors de accept
}ThreadData;

void ThreadData_cpy(ThreadData* t1, ThreadData* t2);
void Statie_cpy(Statie * s1, Statie * s2);
void parseStatie (xmlDocPtr doc, xmlNodePtr ptrCurrNode, Statie * IN);
int atoiTime(xmlChar* str);
void stringConversion(char * A);
bool stringsCompare (char * A, char * B);
int get_current_hour ( );
bool next_hour ( int a);

class Command{
public:
	struct Answer{
		bool done;
		Statie s[300];
		int numb;
	}A;

	ThreadData thD;
	Statie current; 

	void getInput(Statie * A, Statie* B);
	virtual bool check(Statie * B) = 0;
	void answer();
	//~Command();
};



class CommQueue{
public:
	Command* Q[100];
	int len, len2;
	int deltaTime;
	time_t t1, t2;

	CommQueue();
	Command * push_back( int comm_type, ThreadData *thD0, Statie* current0);
	void parseStatie (xmlDocPtr doc, xmlNodePtr ptrCurrNode, Statie * IN);
	void get_intarziere (Statie* B);

	void refresh();
	void get_input(Statie * B);
	void cross_xml();
	void pop ();
};

void CommQueue :: refresh(){
	t2 =time(&t2);
	if ( difftime (t2, t1) > double (0.5) && len > 0){
		t1=t2;
		this -> len2 = this -> len;
		cross_xml();
	}
}

CommQueue :: CommQueue(){
	len = 0;
	len2 = 0;
	t1 = time(&t1);
}

class All : public Command{
public:
	All(ThreadData* thD1, Statie* current1);
	bool check(Statie* B);
};

class Plecari_Ora : public Command{
public:
	Plecari_Ora(ThreadData* thD1, Statie* current1);
	bool check(Statie* B);
};

class Sosiri_Ora: public Command{
public:
	Sosiri_Ora(ThreadData* thD1, Statie* current1);
	bool check(Statie* B);
};

class ruta : public Command{
public:
	ruta (ThreadData* thD1, Statie* current1);
	bool check(Statie* B);
};

class intarziere : public Command{
public:
	intarziere (ThreadData* thD1, Statie* current1);
	bool check(Statie* B);
};

ruta :: ruta (ThreadData* thD1, Statie* current1){
	ThreadData_cpy (& thD, thD1);
	Statie_cpy (& current, current1);
	A.numb = 0;
	A.done = false;
}

intarziere :: intarziere (ThreadData* thD1, Statie* current1){
	ThreadData_cpy (& thD, thD1);
	Statie_cpy (& current, current1);
	A.numb = 0;
	A.done = false;
}

All :: All(ThreadData* thD1, Statie* current1){
	ThreadData_cpy (& thD, thD1);
	Statie_cpy (& current, current1);
	A.numb = 0;
	A.done = false;
}

Plecari_Ora :: Plecari_Ora(ThreadData* thD1, Statie* current1){
	ThreadData_cpy (& thD, thD1);
	Statie_cpy (& current, current1);
	A.numb = 0;
	A.done = false;
}

Sosiri_Ora :: Sosiri_Ora (ThreadData* thD1, Statie* current1){
	ThreadData_cpy (& thD, thD1);
	Statie_cpy (& current, current1);
	A.numb = 0;
	A.done = false;
}

void Command :: getInput(Statie * A, Statie* B){
	Statie_cpy ( A, B);
}

bool All ::check (Statie * B){
	return true;
}

bool Plecari_Ora :: check(Statie* B){
	int a, c;
	a = get_current_hour();
	c = B->plecare;
	bool b = false;
	for (int i =0; i<60; ++i){
		if (a >= 24*60)
			a=0;
		if (a == c)
			b = true;
		a++;
	}
	return stringsCompare(B->nume, current.nume) && b;
}

bool Sosiri_Ora :: check (Statie *B){
	int a, c;
	a = get_current_hour();
	c = B->sosire;
	bool b = false;
	for (int i =0; i<60; ++i){
		if (a >= 24*60)
			a=0;
		if (a == c)
			b = true;
		a++;
	}
	return stringsCompare(B->nume, current.nume) && b;
}

bool ruta :: check(Statie * B){
	return stringsCompare(B->ruta, current.ruta);
}

bool intarziere :: check(Statie * B){
	return stringsCompare(B->ruta, current.ruta) && stringsCompare(B->nume, current.nume);
}

void CommQueue :: pop(){
	int i = 0;
	Command * a;
	while (i < len2 ){
		a = this ->Q[i];
		this->Q[i] = this->Q[i+len2];
		a->A.done = true;
		i++;
	}
	this -> len -= (this ->len2);
}

Command* CommQueue :: push_back (int comm_type, ThreadData* thD0, Statie* current0){
	switch (comm_type){
		case 0:{
			Q[len] = new All(thD0, current0);
			len++;
			return Q[len-1];
			break;
		}

		case 1:{
			Q[len] = new Sosiri_Ora(thD0, current0);
			len++;
			return Q[len-1];
			break;
		}

		case 2:{
			Q[len] = new Plecari_Ora(thD0, current0);
			len++;
			return Q[len-1];
			break;
		}
		case 3:{
			Q[len] = new ruta(thD0, current0);
			len++;
			return Q[len-1];
			break;
		}
		case 4:{
			Q[len] = new intarziere(thD0, current0);
			len++;
			return Q[len-1];
			break;
		}
		default:{
			break;
		}
	}
} 

void Command :: answer(){
	
	int n=0;;
	bool v[300];
	for(int i=0; i< A.numb; ++i){
		v[i] = check( & A.s[i]);
		if(v[i])
			n++;
	}

	char ans[180];
	
	if (write(thD.cl, & n, sizeof(int)) <= 0)
	{
		printf("[Thread %d] ", thD.idThread);
		fflush(stdout);
		perror("[Thread]Eroare la write() catre client.\n");
	}

	int l;

	for (int i = 0; i < A.numb; ++i){
		if(v[i]){
			memset(ans, 0, 180);
			sprintf(ans, "ruta:\n%s \nstatia:\n%s\nsosire: %d:%d \nplecare: %d:%d \nintarziere: %d \n", A.s[i].ruta, A.s[i].nume, A.s[i].sosire/60, A.s[i].sosire%60, A.s[i].plecare/60, A.s[i].plecare%60, A.s[i].intarziere);

			l = strlen(ans)+1;
			if (write(thD.cl, &l, sizeof(int)) <= 0){
				printf("[Thread %d] ", thD.idThread);
				fflush(stdout);
				perror("[Thread]Eroare la write() catre client.\n");
			}

			if (write(thD.cl, ans, strlen(ans)+1) <= 0){
				printf("eroare trimitere raspuns catre clientul %d \n", thD.idThread);
				fflush(stdout);
				perror ("eroare write()\n");
			}
		}
	}
	A.numb = 0;
}

void ThreadData_cpy(ThreadData* t1, ThreadData* t2){
	t1->idThread = t2->idThread;
	t1->cl = t2->cl; 
}

void Statie_cpy(Statie * s1, Statie * s2){
	strcpy ( s1->ruta, s2->ruta);
	strcpy ( s1->nume, s2->nume);
	s1->sosire = s2->sosire;
	s1-> plecare = s2->plecare;
	s1-> intarziere = s2->intarziere;
}

void CommQueue :: get_input (Statie* B){
	for (int i = 0 ; i< len2; ++i){
		Q[i]->getInput ( & (Q[i]->A.s[Q[i]->A.numb]), B);
		(Q[i]->A.numb)++;
	}
}

void CommQueue :: get_intarziere (Statie* B){
	for (int i = 0 ; i< len2; ++i){
		if ((!strcmp (Q[i]->current.nume, B->nume)) && (!strcmp (Q[i]->current.nume, B->nume))){
			B->intarziere= (B->intarziere  + Q[i]->current.intarziere * 2 ) / 3;
		} 
	}
}

void CommQueue :: cross_xml (){
	Statie IN;
	xmlDocPtr document;
	document = xmlParseFile(DATA_BASE);

	if (document == NULL) {
		fprintf(stderr, "Document not parsed successfully. \n");
		printf("notparsed\n");fflush(stdout);
	}

	xmlNodePtr route, station, second;
	route = xmlDocGetRootElement(document);

	if (route == NULL) {
		fprintf(stderr, "empty document\n");
		printf("empty\n");fflush(stdout);
		xmlFreeDoc(document);
	}

	if (xmlStrcmp(route->name, (const xmlChar *) "mersTrenuri")) {
		fprintf(stderr, "document of the wrong type, root node != mersTrenuri");
		printf("empty\n");fflush(stdout);
		xmlFreeDoc(document);
	}

	for (route = route->xmlChildrenNode; route != NULL; route = route->next){
		if (xmlStrcmp(route->name, (const xmlChar *) "ruta") == 0){
				parseStatie ( document, route->xmlChildrenNode->next, & IN);
				this -> get_input(& IN);
		}		
	}

	xmlSaveFormatFile ( DATA_BASE, document, 1);
	xmlFreeDoc(document);
	this -> pop();
} 

void CommQueue :: parseStatie (xmlDocPtr doc, xmlNodePtr ptrCurrNode, Statie * IN){
	xmlChar* str;

	str = xmlNodeListGetString(doc, ptrCurrNode->xmlChildrenNode, 1);
	strcpy (IN->ruta, (char *) str);
	xmlFree(str);
	ptrCurrNode = ptrCurrNode -> next->next;

	str = xmlNodeListGetString(doc, ptrCurrNode->xmlChildrenNode, 1);
	strcpy (IN->nume, (char*) str);
	xmlFree(str);
	ptrCurrNode = ptrCurrNode -> next->next;

	str = xmlNodeListGetString(doc, ptrCurrNode->xmlChildrenNode, 1);
	IN->sosire = atoiTime( str);
	xmlFree(str);
	ptrCurrNode = ptrCurrNode -> next->next;

	str = xmlNodeListGetString(doc, ptrCurrNode->xmlChildrenNode, 1);
	IN->plecare = atoiTime( str);
	xmlFree(str);
	ptrCurrNode = ptrCurrNode -> next->next;


	str = xmlNodeListGetString(doc, ptrCurrNode->xmlChildrenNode, 1);
	IN->intarziere = atoi( (const char *) str);

	if (IN->intarziere < 60) {
		if ( !next_hour (IN -> sosire) )
			IN -> intarziere = 0;

		get_intarziere ( IN);
		char s[10];
		sprintf(s,"%d",IN->intarziere);
		xmlChar * c = xmlCharStrdup ( s );
		xmlNodePtr a = xmlNewText ( c);

		xmlReplaceNode (ptrCurrNode -> xmlChildrenNode, a);
	}

	xmlFree(str);
	ptrCurrNode = ptrCurrNode -> next;
}

int atoiTime(xmlChar* str){
	int h = int(str[0]-'0')* 10 + int(str[1] - '0');
	int m = int(str[3]-'0')* 10 + int(str[4] - '0');
	return m + (60 * h);
}


void stringConversion(char * A){
	for (int i =0; i< strlen(A); ++i){
		if(A[i] >= 'A' && A[i] <= 'Z')
			A[i] += ('a'-'A');
		if (!((A[i] >= 'A' && A[i] <= 'Z') || (A[i] >= 'a' && A[i] <= 'z'))){
			strcpy (A+i, A+i+1);
			i--;
		}
	}
}

bool stringsCompare (char * A, char * B){
	char X[100], Y[100];
	strcpy (X, A);
	stringConversion(X);
	strcpy (Y, B);
	stringConversion(Y);

	if(strcmp(X, Y) == 0) return true;
	return false;
}

int get_current_hour ( ){
	time_t now;
	struct tm *now_tm;
	int hour;

	now = time (NULL);
	now_tm = localtime ( &now);
	return now_tm->tm_hour * 60 + now_tm->tm_min;
}

bool next_hour ( int a){
	int b = get_current_hour();
	for (int i= 0; i<= 120 ; ++i){
		if ( b == 24*60)
			b = 0;
		if ( b == a)
			return true;
		b++;
	}
	return false;
}